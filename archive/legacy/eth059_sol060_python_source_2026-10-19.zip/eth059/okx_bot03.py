import json
import time
import hmac
import base64
import hashlib
import os
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

import websocket
from okx_bot02 import ROOT, CFG, env, INST, api_get

VERSION = "0.3.0"
DURATION = 30

if CFG["live_trading"] is not False:
    raise SystemExit("STOP: DRY RUN required")

if env.get("OKX_DEMO", "0") != "0":
    raise SystemExit("STOP: Unexpected account mode")

LOG = ROOT / "logs" / "orders_v030.jsonl"
STATE = ROOT / "state" / "observation_v030.json"

seen_fills = set()
ws_events = 0
new_fills = 0


def log_event(d):
    fields = (
        "instId", "ordId", "clOrdId", "side",
        "state", "px", "sz", "accFillSz",
        "fillSz", "fillPx", "tradeId",
        "execType", "fillFee", "fillFeeCcy",
        "uTime"
    )

    clean = {k: d.get(k) for k in fields}

    fd = os.open(
        LOG,
        os.O_WRONLY | os.O_CREAT | os.O_APPEND,
        0o600
    )

    with os.fdopen(fd, "a") as f:
        f.write(json.dumps(clean) + "\n")


def save_snapshot(positions, orders, fills):
    snapshot = {
        "version": VERSION,
        "mode": "READ_ONLY_OBSERVATION",
        "time": datetime.now(timezone.utc).isoformat(),
        "instrument": INST,
        "positions": positions,
        "orders": orders,
        "recent_fills_count": len(fills),
        "observed_ws_events": ws_events,
        "observed_new_fills": new_fills,
        "note": "Not authoritative trading state"
    }

    tmp = STATE.with_suffix(".tmp")

    fd = os.open(
        tmp,
        os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
        0o600
    )

    with os.fdopen(fd, "w") as f:
        json.dump(snapshot, f, indent=2)
        f.flush()
        os.fsync(f.fileno())

    os.replace(tmp, STATE)


def rest_check(initial=False):
    global new_fills

    positions = api_get(
        f"/api/v5/account/positions?instId={INST}"
    )

    orders = api_get(
        f"/api/v5/trade/orders-pending?instId={INST}"
    )

    fills = api_get(
        "/api/v5/trade/fills"
        f"?instType=SWAP&instId={INST}&limit=100"
    )

    fresh = []

    for fill in fills:
        trade_id = fill.get("tradeId")

        if not trade_id:
            continue

        key = (INST, trade_id)

        if key not in seen_fills:
            seen_fills.add(key)

            if not initial:
                fresh.append(fill)
                new_fills += 1

    print(
        f"REST | Positions: {len(positions)}"
        f" | Orders: {len(orders)}"
        f" | Recent fills: {len(fills)}"
    )

    for f in fresh:
        print(
            "💥 REST FILL",
            f.get("side"),
            f.get("fillSz"),
            "@", f.get("fillPx"),
            "|", f.get("execType"),
            "| fee:", f.get("fee")
        )

    save_snapshot(positions, orders, fills)


print(f"=== OKX BOT01 v{VERSION} ===")
print("Mode: READ ONLY")
print("Instrument:", INST)
print()

ws = None

try:
    ws = websocket.create_connection(
        "wss://ws.okx.com/ws/v5/private",
        timeout=10,
        header=["User-Agent: curl/8.5.0"]
    )

    print("✅ Private WS connected")

    ts = str(int(time.time()))
    msg = ts + "GET/users/self/verify"

    sign = base64.b64encode(
        hmac.new(
            env["OKX_API_SECRET"].encode(),
            msg.encode(),
            hashlib.sha256
        ).digest()
    ).decode()

    ws.send(json.dumps({
        "op": "login",
        "args": [{
            "apiKey": env["OKX_API_KEY"],
            "passphrase": env["OKX_API_PASSPHRASE"],
            "timestamp": ts,
            "sign": sign
        }]
    }))

    response = json.loads(ws.recv())

    if (
        response.get("event") != "login"
        or response.get("code") != "0"
    ):
        raise RuntimeError(
            "Login failed: " + str(response)
        )

    print("✅ WS authenticated")

    ws.send(json.dumps({
        "op": "subscribe",
        "args": [{
            "channel": "orders",
            "instType": "SWAP",
            "instId": INST
        }]
    }))

    response = json.loads(ws.recv())

    if (
        response.get("event") != "subscribe"
        or response.get("arg", {}).get("channel") != "orders"
    ):
        raise RuntimeError(
            "Subscription failed: " + str(response)
        )

    print("✅ ETH orders channel subscribed")
    print()

    # Start with REST snapshot.
    rest_check(initial=True)

    ws.settimeout(2)

    started = time.monotonic()
    last_rest = started
    last_ping = started

    while time.monotonic() - started < DURATION:
        now = time.monotonic()

        if now - last_ping >= 10:
            ws.send("ping")
            last_ping = now

        try:
            raw = ws.recv()
        except websocket.WebSocketTimeoutException:
            raw = None

        if raw == "ping":
            ws.send("pong")
            continue

        if raw and raw != "pong":
            event = json.loads(raw)

            if event.get("event") == "error":
                raise RuntimeError(str(event))

            if event.get("arg", {}).get("channel") == "orders":
                for d in event.get("data", []):
                    if d.get("instId") != INST:
                        continue

                    ws_events += 1
                    log_event(d)

                    print(
                        "WS ORDER",
                        d.get("side"),
                        d.get("state"),
                        "@", d.get("px"),
                        "| filled:", d.get("accFillSz"),
                        "| trade:", d.get("tradeId")
                    )

        if time.monotonic() - last_rest >= 10:
            rest_check()
            last_rest = time.monotonic()

    print()
    rest_check()

    print("\n=== RESULTS ===")
    print("WS events:", ws_events)
    print("New REST fills:", new_fills)
    print("Snapshot:", STATE)
    print("Event log:", LOG)
    print("✅ READ-ONLY TEST COMPLETE")

except Exception as e:
    print("❌ ERROR:", type(e).__name__, str(e))

finally:
    if ws:
        ws.close()
