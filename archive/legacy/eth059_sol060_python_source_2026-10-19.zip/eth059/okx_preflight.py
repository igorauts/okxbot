import json, hmac, hashlib, base64
import urllib.request, urllib.error
from decimal import Decimal
from datetime import datetime, timezone

env = {}
with open(".env") as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip('"').strip("'")

def get(path):
    ts = datetime.now(timezone.utc).isoformat(
        timespec="milliseconds"
    ).replace("+00:00", "Z")

    msg = ts + "GET" + path

    sign = base64.b64encode(
        hmac.new(
            env["OKX_API_SECRET"].encode(),
            msg.encode(),
            hashlib.sha256
        ).digest()
    ).decode()

    headers = {
        "User-Agent": "curl/8.5.0",
        "OK-ACCESS-KEY": env["OKX_API_KEY"],
        "OK-ACCESS-SIGN": sign,
        "OK-ACCESS-TIMESTAMP": ts,
        "OK-ACCESS-PASSPHRASE": env["OKX_API_PASSPHRASE"]
    }

    if env.get("OKX_DEMO") == "1":
        headers["x-simulated-trading"] = "1"

    req = urllib.request.Request(
        "https://www.okx.com" + path,
        headers=headers
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            result = json.load(r)
    except urllib.error.HTTPError as e:
        raise SystemExit(
            f"HTTP {e.code}: {e.read().decode()[:300]}"
        )
    except Exception as e:
        raise SystemExit(f"Network error: {e}")

    if result.get("code") != "0":
        raise SystemExit(
            f"API error: {result.get('code')} "
            f"{result.get('msg')}"
        )

    return result.get("data", [])

inst = "ETH-USDT-SWAP"

print("=== OKX ETH PREFLIGHT ===")

positions = get(
    f"/api/v5/account/positions?instId={inst}"
)

active_positions = [
    p for p in positions
    if Decimal(p.get("pos") or "0") != 0
]

orders = get(
    f"/api/v5/trade/orders-pending?instId={inst}"
)

algos = []
for kind in ("conditional", "oco", "trigger", "move_order_stop"):
    data = get(
        "/api/v5/trade/orders-algo-pending"
        f"?ordType={kind}&instId={inst}"
    )
    algos.extend(data)

print("Open positions:", len(active_positions))
for p in active_positions:
    print("  Position:", p.get("pos"),
          "Mode:", p.get("mgnMode"))

print("Active orders:", len(orders))
for o in orders:
    print(" ", o.get("side"), o.get("sz"),
          "@", o.get("px"), o.get("state"))

print("Active algo orders:", len(algos))

if not active_positions and not orders and not algos:
    print("✅ ETH ACCOUNT CLEAN")
else:
    print("⚠️ EXISTING ETH EXPOSURE/ORDERS")
    print("⚠️ DO NOT START GRID BOT")
