#!/usr/bin/env python3
"""OKX ETH grid v0.5.1: resumable 20-order LIMIT+attached TP controller.

Never assumes a TP has completed without a terminal filled SELL order that can
be linked to its attached algo client ID. Unknown states fail closed.
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import sys
import fcntl
import shutil
import threading
import queue
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from decimal import Decimal, ROUND_FLOOR
from pathlib import Path

import websocket

ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT / 'config.json').read_text())
DATA = ROOT / 'state' / 'bot04_state.json'
EVENTS = ROOT / 'logs' / 'bot04_events.jsonl'
INST = 'ETH-USDT-SWAP'
STEP, TP, QTY = Decimal('0.25'), Decimal('1.75'), Decimal('0.01')
TARGET, CAP, EX_CAP = 20, 500, 500
INTERVAL = 5
VER = '0.5.1'

def die(s):
    raise RuntimeError(s)

def fmt(x):
    return f'{x:.2f}'

def D(v):
    return Decimal(str(v or '0'))

if (CFG.get('instrument') != INST or CFG.get('direction') != 'long'
    or CFG.get('td_mode') != 'cross' or CFG.get('buy_type') != 'post_only'
    or CFG.get('tp_type') != 'attached_limit'
    or D(CFG.get('grid_step')) != STEP or D(CFG.get('take_profit')) != TP
    or D(CFG.get('order_size')) != QTY
    or CFG.get('active_buy_orders') != TARGET or CFG.get('max_grids') != CAP
    or CFG.get('max_exchange_orders') != EX_CAP):
    die('Configuration mismatch. Refusing to start.')

ENV = {}
for line in (ROOT / '.env').read_text().splitlines():
    line = line.strip()
    if line and not line.startswith('#') and '=' in line:
        k,v=line.split('=',1); ENV[k.strip()]=v.strip().strip('"').strip("'")
if not all(ENV.get(k) for k in ('OKX_API_KEY','OKX_API_SECRET','OKX_API_PASSPHRASE')):
    die('Missing API secrets')
if ENV.get('OKX_DEMO','0') != '0':
    die('Unexpected demo mode')

# Intentional separate live activation guard. Setting config alone is NOT enough.
LIVE = CFG.get('live_trading') is True and os.getenv('OKX_BOT04_LIVE') == 'CONFIRM'
FULL = os.getenv('OKX_BOT04_PROBE') == 'FULL_20'
if CFG.get('live_trading') is True and not LIVE:
    die('Live config requires explicit OKX_BOT04_LIVE=CONFIRM')
if LIVE and not FULL:
    die('LIVE requires OKX_BOT04_PROBE=FULL_20 for the 20-order bot.')


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    tmp = path.with_name(path.name + '.tmp')
    fd = os.open(tmp, os.O_WRONLY|os.O_CREAT|os.O_TRUNC, 0o600)
    with os.fdopen(fd,'w') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)
    dirfd = os.open(path.parent, os.O_RDONLY)
    try: os.fsync(dirfd)
    finally: os.close(dirfd)

def log(event, **details):
    record={'ts':datetime.now(timezone.utc).isoformat(),'event':event,**details}
    fd=os.open(EVENTS,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
    with os.fdopen(fd,'a') as f: f.write(json.dumps(record,ensure_ascii=False)+'\n')
    print(f"[{record['ts'][11:19]}] {event}", details,flush=True)

class API:
    def req(self, method, path, params=None, body=None):
        if method != 'GET' and not LIVE:
            die('Write operations disabled in DRY RUN')
        if params: path += '?' + urllib.parse.urlencode(params)
        payload=json.dumps(body,separators=(',',':')) if body is not None else ''
        ts=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
        msg=ts+method+path+payload
        sig=base64.b64encode(hmac.new(ENV['OKX_API_SECRET'].encode(),msg.encode(),hashlib.sha256).digest()).decode()
        headers={'User-Agent':'curl/8.5.0','Content-Type':'application/json',
            'OK-ACCESS-KEY':ENV['OKX_API_KEY'],'OK-ACCESS-SIGN':sig,
            'OK-ACCESS-TIMESTAMP':ts,'OK-ACCESS-PASSPHRASE':ENV['OKX_API_PASSPHRASE']}
        req=urllib.request.Request('https://www.okx.com'+path,
            data=payload.encode() if body is not None else None,
            method=method,headers=headers)
        try:
            with urllib.request.urlopen(req,timeout=12) as r: result=json.load(r)
        except urllib.error.HTTPError as e:
            die(f'HTTP {e.code} {e.read(400).decode(errors="replace")}')
        except Exception as e:
            die(f'UNKNOWN REQUEST OUTCOME: {type(e).__name__}: {e}')
        if result.get('code') == '51603' and method == 'GET' and path.startswith('/api/v5/trade/order?'):
            # A new attached TP may not yet be queryable via REST.
            # This is not proof of a missing TP. Retry, without placing BUYs.
            return []
        if result.get('code')!='0': die(f"OKX API {result.get('code')}: {result.get('msg')}")
        return result.get('data',[])

    def pending(self):
        # Return ALL relevant orders; fail closed if pagination looks strange.
        result=[]; after=None
        for _ in range(8):
            p={'instType':'SWAP','instId':INST,'limit':'100'}
            if after: p['after']=after
            page=self.req('GET','/api/v5/trade/orders-pending',p)
            result.extend(page)
            if len(page)<100: return result
            nxt=page[-1].get('ordId')
            if not nxt or nxt==after: die('Cannot paginate open orders')
            after=nxt
        die('Pending-order pagination overflow')

    def order(self, oid='', cid=''):
        p={'instId':INST}
        if oid: p['ordId']=oid
        else: p['clOrdId']=cid
        data=self.req('GET','/api/v5/trade/order',p)
        return data[0] if data else None

    def positions(self):
        return self.req('GET','/api/v5/account/positions',{'instId':INST})

    def ticker(self):
        data=self.req('GET','/api/v5/market/ticker',{'instId':INST})
        if not data: die('Ticker missing')
        return D(data[0]['bidPx'])

    def instrument(self):
        data=self.req('GET','/api/v5/public/instruments',{'instType':'SWAP','instId':INST})
        if len(data)!=1: die('Instrument missing')
        v=data[0]
        if v.get('state')!='live' or STEP%D(v['tickSz']) or TP%D(v['tickSz']) or QTY<D(v['minSz']) or QTY%D(v['lotSz']):
            die('Instrument specs incompatible')
        return v

    def history(self):
        # Only use this for strong, exact TP ID correlation, never price matching.
        return self.req('GET','/api/v5/trade/orders-history',{'instType':'SWAP','instId':INST,'limit':'100'})

    def algo(self,cid):
        # The attached algo is only registered after parent BUY fully fills.
        data=self.req('GET','/api/v5/trade/order-algo',{'algoClOrdId':cid})
        return data[0] if data else None

A=API()

def newid(prefix):
    return 'OX4'+prefix+str(int(time.time()*1000))+secrets.token_hex(4)

def save(state):
    atomic_json(DATA,state)

def count(state):
    return sum(x['state'] not in ('CLOSED','CANCELED') for x in state['cycles'].values())

def active_buy(state):
    return [x for x in state['cycles'].values() if x['state'] in ('BUY_LIVE','BUY_PARTIAL','PLACING')]

def level_free(state,price):
    key=fmt(price)
    return key not in state['cycles'] or state['cycles'][key]['state'] in ('CLOSED','CANCELED')

def run_tests():
    # Exact rule requested: a partially filled TP NEVER releases its level.
    demo={'cycles': {'2500.00':{'state':'TP_PARTIAL'}}}
    assert not level_free(demo,Decimal('2500'))
    demo['cycles']['2500.00']['state']='TP_WAIT'
    assert not level_free(demo,Decimal('2500'))
    demo['cycles']['2500.00']['state']='CLOSED'
    assert level_free(demo,Decimal('2500'))
    log('UNIT_TESTS_OK', rule='TP_PARTIAL stays occupied')

def initial_state():
    pos=A.positions(); pending=A.pending()
    if any(D(p.get('pos'))!=0 for p in pos) or pending:
        die('Untracked ETH positions/orders. Refusing to initialize.')
    st={'version':VER,'instrument':INST,'cycles':{},'completed':0,'bootstrapped':True}
    save(st); return st

def verify_existing(st,pending):
    # Under a net-mode account, any outside ETH trading invalidates our ledger.
    known_ids={x.get('ordId') for x in st['cycles'].values() if x.get('ordId')}
    known_tp_ids={x.get('tpOrdId') for x in st['cycles'].values() if x.get('tpOrdId')}
    known_tp_client_ids={x.get('tpClOrdId') for x in st['cycles'].values() if x.get('tpClOrdId')}
    unknown=[o for o in pending if o.get('ordId') not in known_ids|known_tp_ids
             and not (o.get('side')=='sell' and (
                 o.get('clOrdId') in known_tp_client_ids or
                 o.get('algoClOrdId') in known_tp_client_ids))]
    if unknown:
        die('Unrecognized open order(s): '+','.join(o.get('ordId','?') for o in unknown[:5]))

def track(st, pending):
    """Reconcile every cycle using real BUY/SELL order IDs.

    Attached LIMIT TP is a regular SELL once activated, NOT necessarily an
    accessible algo order. Client ID given in attachAlgoClOrdId is propagated
    to the resulting SELL (verified on OKX private orders WS).
    Return False on transient TP synchronization; callers MUST NOT place BUYs.
    """
    all_resolved = True
    for key, x in list(st['cycles'].items()):
        status = x['state']
        if status in ('CLOSED', 'CANCELED'):
            continue
        if status == 'PLACING':
            o = A.order(cid=x['clOrdId'])
            if not o:
                die('Uncertain BUY placement '+x['clOrdId']+'; manual reconciliation')
            x['ordId']=o['ordId']; x['state']='BUY_LIVE'; save(st)
            status='BUY_LIVE'
        if status == 'CANCELING':
            o=A.order(oid=x['ordId'])
            if not o: die('Cannot confirm cancellation at '+key)
            if o.get('state')=='canceled' and D(o.get('accFillSz'))==0:
                x['state']='CANCELED';save(st);continue
            die('Ambiguous BUY cancellation with possible fill at '+key)
        if status in ('BUY_LIVE', 'BUY_PARTIAL'):
            o=A.order(oid=x['ordId'])
            if not o: die('BUY unavailable: '+x['ordId']+'; manual reconciliation')
            state=o.get('state'); filled=D(o.get('accFillSz'))
            if state=='filled':
                x['state']='TP_WAIT';x['filledBuy']=str(filled);save(st)
                log('BUY_FILLED',price=key,ordId=x['ordId'],tp=x['tpPx'])
            elif state=='partially_filled':
                x['state']='BUY_PARTIAL';x['filledBuy']=str(filled);save(st)
            elif state=='live':
                if status!='BUY_LIVE': x['state']='BUY_LIVE';save(st)
            elif state in ('canceled','mmp_canceled'):
                if filled: die('BUY canceled after partial execution at '+key)
                x['state']='CANCELED';save(st)
                log('BUY_CANCELED',price=key)
                continue
            else: die('Unknown BUY state '+str(state))

        if x['state'] not in ('TP_WAIT', 'TP_PARTIAL'):
            continue
        cid=x['tpClOrdId']
        tp_id=x.get('tpOrdId','')
        t=None
        matching_pending=[o for o in pending if o.get('side')=='sell' and (
            o.get('clOrdId')==cid or o.get('algoClOrdId')==cid)]
        if len(matching_pending)>1:
            die('Multiple active TP orders with same client ID at '+key)
        if tp_id:
            # The exchange's active-order snapshot is authoritative for live TP.
            t=next((o for o in matching_pending if o.get('ordId')==tp_id),None)
            if t is None: t=A.order(oid=tp_id)
        else:
            if matching_pending:
                t=matching_pending[0]
            else:
                # Try ordinary SELL, not /trade/order-algo. LIMIT TP produces a
                # regular order, and /order-algo may return 51603.
                t=A.order(cid=cid)
                if t is None:
                    hist=[o for o in A.history() if o.get('side')=='sell' and (
                        o.get('clOrdId')==cid or o.get('algoClOrdId')==cid)]
                    if len(hist)>1: die('Ambiguous historical TP at '+key)
                    if hist: t=hist[0]
            if t:
                tp_id=t.get('ordId','')
                if not tp_id: die('TP with missing exchange order ID '+key)
                x['tpOrdId']=tp_id;save(st)
                log('TP_LINKED',price=key,tpOrdId=tp_id,clOrdId=cid)

        if t is None:
            # An unmatched TP is dangerous: hold the level and stop new BUYs.
            first=x.setdefault('tpMissingSince',time.time())
            save(st)
            if time.time()-first > 60:
                die('TP still not queryable after 60s at '+key+
                    '; verify SELL and position manually (no new orders)')
            all_resolved=False
            continue
        if x.pop('tpMissingSince',None) is not None: save(st)
        if t.get('instId')!=INST or t.get('side')!='sell':
            die('TP instrument/side mismatch at '+key)
        # Verify true identity; do not match a random SELL by size and price.
        if t.get('clOrdId') != cid and t.get('algoClOrdId') != cid:
            die('TP client ID mismatch at '+key)
        if D(t.get('sz'))!=D(x.get('filledBuy')):
            die('TP total quantity mismatch at '+key)
        if D(t.get('px'))!=D(x.get('tpPx')):
            die('TP price mismatch at '+key)
        tstate=t.get('state')
        filled_tp=D(t.get('accFillSz'))
        if filled_tp > D(x['filledBuy']):
            die('TP filled more than BUY at '+key)
        x['filledTP']=str(filled_tp);save(st)
        if tstate=='filled' and filled_tp==D(x['filledBuy']):
            x['state']='CLOSED';st['completed']+=1;save(st)
            log('TP_FILLED',price=key,tpId=tp_id)
        elif tstate=='partially_filled':
            if x['state']!='TP_PARTIAL':
                x['state']='TP_PARTIAL';save(st)
                log('TP_PARTIAL',price=key,filled=str(filled_tp),total=x['filledBuy'])
        elif tstate in ('canceled','mmp_canceled'):
            die('TP canceled, unclosed exposure at '+key+'; manual review')
        elif tstate=='filled':
            die('TP filled with wrong volume at '+key)
        elif tstate!='live':
            die('Unknown TP order status '+str(tstate))
    return all_resolved

def place(st,px):
    k=fmt(px); tp=fmt(px+TP)
    previous=st['cycles'].get(k)
    if previous:
        if previous['state'] not in ('CLOSED','CANCELED'):
            die('Level already occupied: '+k)
        st.setdefault('archived_cycles',[]).append({'level':k,**previous})
        save(st)
    cl=newid('B'); tcl=newid('T')
    x={'state':'PLACING','buyPx':k,'tpPx':tp,'sz':str(QTY),
       'clOrdId':cl,'tpClOrdId':tcl,'ordId':'','tpOrdId':''}
    st['cycles'][k]=x; save(st)  # durable intent BEFORE network request
    req={'instId':INST,'tdMode':'cross','side':'buy','posSide':'net',
         'ordType':'post_only','px':k,'sz':str(QTY),'clOrdId':cl,
         'attachAlgoOrds':[{'attachAlgoClOrdId':tcl,'tpOrdKind':'limit','tpOrdPx':tp}]}
    data=A.req('POST','/api/v5/trade/order',body=req)
    if len(data)!=1:
        die('Unexpected place-order response: '+str(data))
    if data[0].get('sCode') != '0':
        # Positive OKX rejection acknowledgement: no order was placed.
        x['state']='CANCELED'; x['rejectCode']=data[0].get('sCode'); save(st)
        log('BUY_REJECTED',price=k,code=x['rejectCode'],msg=data[0].get('sMsg',''))
        # Recalculate on next market snapshot; don't blindly resend here.
        return False
    if not data[0].get('ordId'):
        die('Order accepted without ID: manual check required')
    x['ordId']=data[0]['ordId']; x['state']='BUY_LIVE'; save(st)
    log('BUY_PLACED',price=k,tp=tp,ordId=x['ordId'])
    return True

def cancel_lowest_specific(st,lowest):
    oid=lowest['ordId']
    # Durable intent, same discipline as placing orders.
    lowest['state']='CANCELING'; save(st)
    data=A.req('POST','/api/v5/trade/cancel-order',body={'instId':INST,'ordId':oid})
    if len(data)!=1 or data[0].get('sCode')!='0':
        die('Cancellation not accepted: '+str(data))
    o=A.order(oid=oid)
    if not o or o.get('state') not in ('canceled','filled','partially_filled'):
        die('Cancellation not yet final; STOP until verified')
    if D(o.get('accFillSz'))>0:
        die('BUY filled during cancellation: manual review required')
    if o.get('state')!='canceled':
        die('BUY cancellation did not complete')
    lowest['state']='CANCELED'; save(st)
    log('BUY_MOVED_UP',cancelled=lowest['buyPx'],ordId=oid)
    return True

class WSWatcher(threading.Thread):
    """Private order event stream; REST remains the authority for reconciliation."""
    def __init__(self):
        super().__init__(daemon=True)
        self.events=queue.Queue(maxsize=1000)
        self.connected=False
    def run(self):
        while True:
            ws=None
            try:
                ws=websocket.create_connection('wss://ws.okx.com/ws/v5/private',
                    timeout=12,header=['User-Agent: curl/8.5.0'])
                ts=str(int(time.time()))
                msg=ts+'GET/users/self/verify'
                sig=base64.b64encode(hmac.new(ENV['OKX_API_SECRET'].encode(),
                    msg.encode(),hashlib.sha256).digest()).decode()
                ws.send(json.dumps({'op':'login','args':[{'apiKey':ENV['OKX_API_KEY'],
                    'passphrase':ENV['OKX_API_PASSPHRASE'],'timestamp':ts,'sign':sig}]}))
                ans=json.loads(ws.recv())
                if ans.get('event')!='login' or ans.get('code')!='0': die('WS login '+str(ans))
                ws.send(json.dumps({'op':'subscribe','args':[{'channel':'orders',
                    'instType':'SWAP','instId':INST}]}))
                ans=json.loads(ws.recv())
                if ans.get('event')!='subscribe': die('WS subscribe '+str(ans))
                self.connected=True
                ws.settimeout(5); last_ping=time.monotonic()
                while True:
                    if time.monotonic()-last_ping>=15:
                        ws.send('ping');last_ping=time.monotonic()
                    try: raw=ws.recv()
                    except websocket.WebSocketTimeoutException: continue
                    if raw=='ping': ws.send('pong');continue
                    if raw=='pong':continue
                    parsed=json.loads(raw)
                    if parsed.get('event')=='error': die('WS event error '+str(parsed))
                    if parsed.get('arg',{}).get('channel')=='orders':
                        for item in parsed.get('data',[]):
                            if item.get('instId')==INST:
                                safe={k:item.get(k) for k in ('ordId','clOrdId','algoClOrdId',
                                    'side','state','accFillSz','fillSz','tradeId')}
                                self.events.put_nowait(safe)
            except Exception as e:
                self.connected=False
                # Never log authentication messages containing credentials.
                print('[WS] reconnect in 5s:',type(e).__name__,flush=True)
                time.sleep(5)
            finally:
                self.connected=False
                if ws:
                    try: ws.close()
                    except Exception: pass


def acquire_lock():
    path=ROOT/'state'/'bot05.lock'
    fd=os.open(path,os.O_CREAT|os.O_RDWR,0o600)
    try:
        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        os.close(fd)
        die('Another OKX bot05 instance is already running. STOP it first.')
    return fd


def ensure_state():
    if DATA.exists():
        st=json.loads(DATA.read_text())
        if st.get('instrument') != INST: die('Wrong state instrument')
        previous_version=st.get('version')
        if previous_version in ('0.4.1','0.5.0'):
            backup=DATA.with_name('bot04_state_before_v051.json')
            if not backup.exists():
                shutil.copy2(DATA,backup)
                os.chmod(backup,0o600)
            st['version']=VER
            st.setdefault('archived_cycles',[])
            save(st)
            log('STATE_UPGRADED',from_version=previous_version,to_version=VER,
                preserved_cycles=len(st['cycles']))
        elif previous_version != VER:
            die('Unsupported old state version: '+str(previous_version))
        return st
    if not LIVE:
        return {'cycles':{},'completed':0,'version':VER,'instrument':INST}
    return initial_state()


def live_loop(st,watcher):
    while True:
        while not watcher.events.empty():
            log('WS_ORDER',**watcher.events.get_nowait())
        pending=A.pending()
        all_resolved=track(st,pending)
        verify_existing(st,pending)
        positions=A.positions()
        expected=sum((D(x.get('filledBuy'))-D(x.get('filledTP'))
                      for x in st['cycles'].values()), Decimal('0'))
        actual=sum((D(p.get('pos')) for p in positions),Decimal('0'))
        if LIVE and actual!=expected:
            # No new BUY orders until discrepancy is resolved.
            # The exchange may lag briefly during trade settlement.
            time.sleep(1)
            actual=sum(D(p.get('pos')) for p in A.positions())
            if actual!=expected:
                die(f'Position mismatch! exchange={actual} local={expected}; no new BUY')
        if not all_resolved:
            # Delay is expected immediately after BUY fill; never treat it as
            # an empty available grid or submit new entries during the gap.
            print('WAIT_TP_SYNC: no new BUY until attached SELL is verified',flush=True)
            time.sleep(INTERVAL)
            continue
        bid=A.ticker()
        top=(bid/STEP).to_integral_value(rounding=ROUND_FLOOR)*STEP
        if top>=bid: top-=STEP
        active=active_buy(st)
        if len(active)>TARGET: die('More than 20 active BUYs')
        # Dynamic upward movement: cancel the lowest stale BUY when BID moves
        # beyond the highest placed BUY; no downward chasing/cancellation.
        if LIVE and len(active)>=TARGET:
            occupied_tp={D(k) for k,x in st['cycles'].items()
                if x['state'] in ('TP_WAIT','TP_PARTIAL')}
            desired=set();p=top
            while len(desired)<TARGET and p>0:
                if p not in occupied_tp:desired.add(p)
                p-=STEP
            active_prices={D(x['buyPx']) for x in active}
            highest=max(active_prices)
            if top>=highest and (desired-active_prices):
                obsolete=[x for x in active if D(x['buyPx']) not in desired
                    and x['state']=='BUY_LIVE']
                if obsolete:
                    cancel_lowest_specific(st,min(obsolete,key=lambda x:D(x['buyPx'])))
                    continue
        # Reserve capacity for active attached TP orders (already in pending
        # if posted); don't confuse hard strategy cap and exchange cap.
        cap=max(0,min(TARGET-len(active),CAP-count(st),EX_CAP-len(pending)))
        candidates=[];p=top
        while len(candidates)<cap and p>0:
            if level_free(st,p):candidates.append(p)
            p-=STEP
        if not LIVE:
            print('DRY RUN', 'BID',bid,'current BUY',len(active),
                  'occupied',count(st),'would place',
                  [(fmt(p),fmt(p+TP)) for p in candidates],flush=True)
            break
        placed=0
        for price in candidates:
            # Respect grid occupancy even if the same price has been recycled.
            if not level_free(st,price):continue
            if len(active_buy(st))>=TARGET or count(st)>=CAP:break
            if place(st,price):
                placed+=1
            else:
                # Price raced through a post-only level: refresh next iteration.
                break
            # Throttle to avoid hammering the API. Sequential posting
            # should deploy 19 new orders within a few seconds.
            time.sleep(0.10)
        print(f'BID={bid} BUY={len(active_buy(st))}/{TARGET} '
              f'occupied={count(st)}/{CAP} closed={st["completed"]} '
              f'new={placed}',flush=True)
        time.sleep(INTERVAL)


def main():
    lock=acquire_lock()
    try:
        print(f'=== OKX BOT01 v{VER} ===',
              'LIVE 20 BUY' if LIVE else 'READ ONLY',flush=True)
        run_tests()
        a=A.req('GET','/api/v5/account/config')
        if not a or a[0].get('posMode')!='net_mode': die('Only net_mode supported')
        A.instrument()
        st=ensure_state()
        watcher=WSWatcher();watcher.start()
        log('START',live=LIVE,tracked=count(st))
        live_loop(st,watcher)
    finally:
        os.close(lock)

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt: print('\nStopped (open orders remain on OKX).',flush=True)
    except Exception as exc:
        print('⛔ STOP:',str(exc),file=sys.stderr,flush=True)
        sys.exit(1)
