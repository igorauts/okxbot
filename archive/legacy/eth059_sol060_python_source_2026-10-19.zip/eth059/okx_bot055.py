#!/usr/bin/env python3
"""OKX ETH grid v0.5.4: resumable 20-order LIMIT+attached TP controller.

Never assumes a TP has completed without a terminal filled SELL order that can
be linked to its attached algo client ID. Unknown states fail closed.
"""
import base64
import hashlib
import hmac
import json
import os
import copy
import secrets
import sys
import fcntl
import shutil
import threading
import queue
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from decimal import Decimal, ROUND_FLOOR, ROUND_HALF_UP
from pathlib import Path

import websocket

ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT / 'config.json').read_text())
DATA = ROOT / 'state' / 'bot04_state.json'
EVENTS = ROOT / 'logs' / 'bot04_events.jsonl'
INST = 'ETH-USDT-SWAP'
STEP, TP, QTY = Decimal('0.25'), Decimal('1.75'), Decimal('0.01')
TARGET, CAP, EX_CAP = 20, 500, 500
INTERVAL = 1.0  # main safety loop; BID updates independently via public WS
VER = '0.5.5'
PNL_DATA = ROOT / 'state' / 'bot05_pnl.json'
CONTRACT_VALUE = Decimal('0.1')  # ETH per contract (verified dynamically at startup)
PRICE_STEP = STEP
USDT_QUANT = Decimal('0.000001')

def die(s):
    raise RuntimeError(s)

def fmt(x):
    return f'{x:.2f}'

def D(v):
    return Decimal(str(v or '0'))

if (CFG.get('instrument') != INST or CFG.get('direction') != 'long'
    or CFG.get('td_mode') != 'cross' or CFG.get('buy_type') != 'post_only'
    or CFG.get('tp_type') != 'attached_limit'
    or D(CFG.get('grid_step')) != STEP or D(CFG.get('take_profit')) != TP
    or D(CFG.get('order_size')) != QTY
    or CFG.get('active_buy_orders') != TARGET or CFG.get('max_grids') != CAP
    or CFG.get('max_exchange_orders') != EX_CAP):
    die('Configuration mismatch. Refusing to start.')

ENV = {}
for line in (ROOT / '.env').read_text().splitlines():
    line = line.strip()
    if line and not line.startswith('#') and '=' in line:
        k,v=line.split('=',1); ENV[k.strip()]=v.strip().strip('"').strip("'")
if not all(ENV.get(k) for k in ('OKX_API_KEY','OKX_API_SECRET','OKX_API_PASSPHRASE')):
    die('Missing API secrets')
if ENV.get('OKX_DEMO','0') != '0':
    die('Unexpected demo mode')

# Intentional separate live activation guard. Setting config alone is NOT enough.
# Audit mode may be used even when live_trading=true in the config.
# It cannot submit or cancel orders: API.req prevents non-GET methods.
STATS_ONLY = os.getenv('OKX_BOT05_STATS') == 'ONCE'
AUDIT = os.getenv('OKX_BOT04_AUDIT') == 'READ_ONLY' or STATS_ONLY
LIVE = (not AUDIT and CFG.get('live_trading') is True
        and os.getenv('OKX_BOT04_LIVE') == 'CONFIRM')
FULL = os.getenv('OKX_BOT04_PROBE') == 'FULL_20'
if CFG.get('live_trading') is True and not LIVE and not AUDIT:
    die('Live config requires explicit OKX_BOT04_LIVE=CONFIRM')
if LIVE and not FULL:
    die('LIVE requires OKX_BOT04_PROBE=FULL_20 for the 20-order bot.')


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    tmp = path.with_name(path.name + '.tmp')
    fd = os.open(tmp, os.O_WRONLY|os.O_CREAT|os.O_TRUNC, 0o600)
    with os.fdopen(fd,'w') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)
    dirfd = os.open(path.parent, os.O_RDONLY)
    try: os.fsync(dirfd)
    finally: os.close(dirfd)

def log(event, **details):
    record={'ts':datetime.now(timezone.utc).isoformat(),'event':event,**details}
    fd=os.open(EVENTS,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
    with os.fdopen(fd,'a') as f: f.write(json.dumps(record,ensure_ascii=False)+'\n')
    t = record['ts'][11:19]
    # Full structured events remain in logs/bot04_events.jsonl, even when
    # we suppress redundant terminal messages from the WebSocket stream.
    if event == 'WS_ORDER':
        return
    if event == 'BUY_PLACED':
        print(f"📌 BUY {details['price']} → TP {details['tp']} | LIMIT", flush=True)
    elif event == 'BUY_FILLED':
        print(f"💥 Вход {details['price']} исполнен → ждём TP {details['tp']}",flush=True)
    elif event == 'TP_FILLED':
        # Money lines follow when individual exchange fills can be verified.
        pass
    elif event == 'TP_LINKED':
        print(f"🔗 TP {details['price']} привязан | SELL {details['tpOrdId']}",flush=True)
    elif event == 'BUY_MOVED_UP':
        print(f"↗️ Сетка вверх | отменён BUY {details['cancelled']}",flush=True)
    elif event == 'POSITION_SYNC_WAIT':
        print(f"⏳ Сверка позиции: биржа {details['exchange']} / бот {details['local']}",flush=True)
    elif event == 'POSITION_SYNC_OK':
        print(f"✅ Позиция синхронизирована: {details['exchange']}",flush=True)
    else:
        print(f"[{t}] {event}",details,flush=True)

class API:
    def req(self, method, path, params=None, body=None):
        if method != 'GET' and not LIVE:
            die('Write operations disabled in DRY RUN')
        if params: path += '?' + urllib.parse.urlencode(params)
        payload=json.dumps(body,separators=(',',':')) if body is not None else ''
        ts=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
        msg=ts+method+path+payload
        sig=base64.b64encode(hmac.new(ENV['OKX_API_SECRET'].encode(),msg.encode(),hashlib.sha256).digest()).decode()
        headers={'User-Agent':'curl/8.5.0','Content-Type':'application/json',
            'OK-ACCESS-KEY':ENV['OKX_API_KEY'],'OK-ACCESS-SIGN':sig,
            'OK-ACCESS-TIMESTAMP':ts,'OK-ACCESS-PASSPHRASE':ENV['OKX_API_PASSPHRASE']}
        req=urllib.request.Request('https://www.okx.com'+path,
            data=payload.encode() if body is not None else None,
            method=method,headers=headers)
        try:
            with urllib.request.urlopen(req,timeout=12) as r: result=json.load(r)
        except urllib.error.HTTPError as e:
            die(f'HTTP {e.code} {e.read(400).decode(errors="replace")}')
        except Exception as e:
            die(f'UNKNOWN REQUEST OUTCOME: {type(e).__name__}: {e}')
        if result.get('code') == '51603' and method == 'GET' and path.startswith('/api/v5/trade/order?'):
            # A new attached TP may not yet be queryable via REST.
            # This is not proof of a missing TP. Retry, without placing BUYs.
            return []
        if result.get('code')!='0': die(f"OKX API {result.get('code')}: {result.get('msg')}")
        return result.get('data',[])

    def pending(self):
        # Return ALL relevant orders; fail closed if pagination looks strange.
        result=[]; after=None
        for _ in range(8):
            p={'instType':'SWAP','instId':INST,'limit':'100'}
            if after: p['after']=after
            page=self.req('GET','/api/v5/trade/orders-pending',p)
            result.extend(page)
            if len(page)<100: return result
            nxt=page[-1].get('ordId')
            if not nxt or nxt==after: die('Cannot paginate open orders')
            after=nxt
        die('Pending-order pagination overflow')

    def order(self, oid='', cid=''):
        p={'instId':INST}
        if oid: p['ordId']=oid
        else: p['clOrdId']=cid
        data=self.req('GET','/api/v5/trade/order',p)
        return data[0] if data else None

    def positions(self):
        return self.req('GET','/api/v5/account/positions',{'instId':INST})

    def ticker(self):
        data=self.req('GET','/api/v5/market/ticker',{'instId':INST})
        if not data: die('Ticker missing')
        return D(data[0]['bidPx'])

    def instrument(self):
        data=self.req('GET','/api/v5/public/instruments',{'instType':'SWAP','instId':INST})
        if len(data)!=1: die('Instrument missing')
        v=data[0]
        if v.get('state')!='live' or STEP%D(v['tickSz']) or TP%D(v['tickSz']) or QTY<D(v['minSz']) or QTY%D(v['lotSz']):
            die('Instrument specs incompatible')
        return v

    def history(self):
        # Only use this for strong, exact TP ID correlation, never price matching.
        return self.req('GET','/api/v5/trade/orders-history',{'instType':'SWAP','instId':INST,'limit':'100'})

    def fills_by_order(self, order_id):
        """Actual fill records, filtered by exact exchange ordId.

        History covers ~3 months. Never calculate profit from a limit price or
        an order-summary fee estimate. A fully populated page requires a
        separate paginated implementation, so fail PnL closed in that case.
        """
        result=self.req('GET','/api/v5/trade/fills-history',{
            'instType':'SWAP','instId':INST,'ordId':order_id,'limit':'100'
        })
        if len(result)>=100:
            raise RuntimeError('100+ fills for one order; detailed pagination required')
        if any(str(f.get('ordId'))!=str(order_id) or f.get('instId')!=INST
               for f in result):
            raise RuntimeError('Order fill filter mismatch; financial record unsafe')
        return result

    def algo(self,cid):
        # The attached algo is only registered after parent BUY fully fills.
        data=self.req('GET','/api/v5/trade/order-algo',{'algoClOrdId':cid})
        return data[0] if data else None

A=API()

def newid(prefix):
    return 'OX4'+prefix+str(int(time.time()*1000))+secrets.token_hex(4)

def save(state):
    atomic_json(DATA,state)

def count(state):
    return sum(x['state'] not in ('CLOSED','CANCELED') for x in state['cycles'].values())

def active_buy(state):
    return [x for x in state['cycles'].values() if x['state'] in ('BUY_LIVE','BUY_PARTIAL','PLACING')]

def level_free(state,price):
    key=fmt(price)
    return key not in state['cycles'] or state['cycles'][key]['state'] in ('CLOSED','CANCELED')

def money(value, places=6):
    x=Decimal(str(value)).quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP)
    return ('+' if x>=0 else '−') + f'{abs(x):.{places}f}'


def money_usdt(value, places=6):
    signed=money(value,places)
    return signed[0]+'$'+signed[1:]


def bold(value):
    return ('\033[1m'+value+'\033[0m') if sys.stdout.isatty() else value


class PnLLedger:
    """Non-trading cycle PnL ledger. All entries sourced from real OKX fills.

    Separate state file prevents a stats bug from mutating trading positions.
    Stored cycle keys are unique BUY+TP IDs; rearming a grid never double-counts.
    """
    def __init__(self, contract_value):
        self.contract_value=contract_value
        if self.contract_value<=0: die('Invalid contract size for profit accounting')
        if PNL_DATA.exists():
            self.data=json.loads(PNL_DATA.read_text())
            if (self.data.get('schema')!=1 or self.data.get('instrument')!=INST):
                die('PnL ledger version/instrument mismatch')
        else:
            self.data={'schema':1,'instrument':INST,'accounted':{}}
        self.tried={}
        self.retry_after={}
        self.recent_total=self.total()
        self.initial_ids=set()

    def total(self):
        return sum((D(p['net']) for p in self.data['accounted'].values()),Decimal(0))

    def recorded(self, cycle):
        return self.identity(cycle) in self.data['accounted']

    @staticmethod
    def identity(cycle):
        if not cycle.get('ordId') or not cycle.get('tpOrdId'):
            return None
        return str(cycle['ordId'])+':'+str(cycle['tpOrdId'])

    def all_cycles(self, st):
        # Includes previously replaced grid levels: completed cycles are
        # archived by place() so their realized PnL must never disappear.
        previous=list(st.get('archived_cycles',[]))
        current=list(st['cycles'].values())
        return [x for x in previous+current if x.get('state')=='CLOSED']

    @staticmethod
    def aggregate(fills, oid, size, side):
        if not fills: raise ValueError('Fills not yet available')
        q=Decimal('0'); amt=Decimal('0'); fee=Decimal('0'); liquidity=set(); ids=set()
        for f in fills:
            if str(f.get('ordId'))!=str(oid): raise ValueError('Unexpected fill order ID')
            if f.get('side') != side: raise ValueError('Wrong side for order fills')
            tid=f.get('tradeId')
            if not tid or tid in ids: raise ValueError('Missing/duplicate tradeId')
            ids.add(tid)
            fs=D(f.get('fillSz')); fp=D(f.get('fillPx'))
            if fs<=0 or fp<=0: raise ValueError('Invalid fill price or size')
            if f.get('feeCcy')!='USDT':
                raise ValueError('Commission currency not USDT; cannot calculate USDT net')
            if f.get('fee') in (None,''): raise ValueError('Missing actual exchange fee')
            if f.get('execType') not in ('M','T'):
                raise ValueError('Missing Maker/Taker execution type')
            q+=fs; amt+=fs*fp; fee+=D(f['fee']);liquidity.add(f['execType'])
        if q!=size: raise ValueError(f'Fill volume differs: {q} != {size}')
        return {'qty':q,'avg_px':amt/q,'fee':fee,'liquidity':'/'.join(sorted(liquidity))}

    def compute(self, cycle, buy_fills, sell_fills):
        amount=D(cycle.get('filledBuy'))
        if amount<=0 or amount!=D(cycle.get('filledTP')):
            raise ValueError('Incomplete cycle cannot have realized profit')
        b=self.aggregate(buy_fills,cycle['ordId'],amount,'buy')
        s=self.aggregate(sell_fills,cycle['tpOrdId'],amount,'sell')
        base_qty=amount*self.contract_value
        gross=(s['avg_px']-b['avg_px'])*base_qty
        plan=(D(cycle['tpPx'])-D(cycle['buyPx']))*base_qty
        execution=gross-plan
        fees=b['fee']+s['fee'] # negative fees, positive rebates
        net=gross+fees
        return {'buy_id':cycle['ordId'],'sell_id':cycle['tpOrdId'],
                'buy_px':str(b['avg_px']),'sell_px':str(s['avg_px']),
                'qty_contracts':str(amount),'qty_eth':str(base_qty),
                'gross':str(gross),'planned_gross':str(plan),
                'execution':str(execution),'fees':str(fees),'net':str(net),
                'buy_liquidity':b['liquidity'],'sell_liquidity':s['liquidity'],
                'accounted_at':datetime.now(timezone.utc).isoformat()}

    def print_closed(self, result, historical=False):
        buy=D(result['buy_px']); sell=D(result['sell_px'])
        steps=(sell-buy)/STEP
        total=self.total()
        earned=bold(money_usdt(result['net']))
        overall=bold(money_usdt(total))
        note=' | история' if historical else ''
        print(f"💰 TP {buy:.2f} → {sell:.2f} | {money(steps,2)} шага "
              f"| в копилку {earned} | всего {overall}{note}",flush=True)
        print(f"   факт {money(result['gross'])} "
              f"(план {money(result['planned_gross'])}, "
              f"execution {money(result['execution'])}, "
              f"комиссия {money(result['fees'])}) "
              f"| {result['buy_liquidity']}/{result['sell_liquidity']}",flush=True)

    def work(self, st, max_cycles=1, historical=True):
        # Data enrichment only: NOT part of placing, canceling, syncing orders.
        # A missing/slow fills-history response cannot trigger new trades.
        pending=[c for c in self.all_cycles(st) if self.identity(c) and not self.recorded(c)]
        if not pending: return
        # Newest first so current closures are visible before long backfills.
        pending.sort(key=lambda x: str(x.get('tpOrdId','')),reverse=True)
        now=time.monotonic(); checked=0
        for c in pending:
            key=self.identity(c)
            if now<self.retry_after.get(key,0): continue
            try:
                buy=A.fills_by_order(c['ordId'])
                sell=A.fills_by_order(c['tpOrdId'])
                r=self.compute(c,buy,sell)
                updated={'schema':1,'instrument':INST,
                         'accounted':{**self.data['accounted'],key:r}}
                atomic_json(PNL_DATA,updated)
                self.data=updated
                # 'historical' means this was missed on a previous run; recorded
                # after the bot has been restarted or while draining old cycles.
                self.print_closed(r, historical=key in self.initial_ids)
                self.tried.pop(key,None)
                self.retry_after.pop(key,None)
            except Exception as e:
                # A PnL record MUST NOT be fabricated if OKX hasn't published
                # fills yet. Defer/retry; trading reconciliation is independent.
                count=self.tried.get(key,0)+1
                self.tried[key]=count
                self.retry_after[key]=now+min(60,5*count)
                if count==1 or count%5==0:
                    print('⏳ TP прибыль ожидает данные OKX:',
                          c.get('buyPx'),type(e).__name__,str(e)[:140],flush=True)
            checked+=1
            if checked>=max_cycles:break

    def status(self, st):
        unaccounted=sum(bool(self.identity(c)) and not self.recorded(c)
                        for c in self.all_cycles(st))
        return f'всего {money_usdt(self.total())} | PnL ожидают {unaccounted}'


def run_tests():
    # Exact rule requested: a partially filled TP NEVER releases its level.
    demo={'cycles': {'2500.00':{'state':'TP_PARTIAL'}}}
    assert not level_free(demo,Decimal('2500'))
    demo['cycles']['2500.00']['state']='TP_WAIT'
    assert not level_free(demo,Decimal('2500'))
    demo['cycles']['2500.00']['state']='CLOSED'
    assert level_free(demo,Decimal('2500'))
    assert grid_top(Decimal('2522.62'))==Decimal('2522.50')
    assert grid_top(Decimal('2522.50'))==Decimal('2522.25')
    desired=desired_buy_levels(Decimal('2522.50'),set())
    assert len(desired)==TARGET
    assert min(desired)==Decimal('2517.75')
    assert max(desired)==Decimal('2522.50')
    assert Decimal('2500.00') not in desired_buy_levels(
        Decimal('2500.50'),{Decimal('2500.00')})
    log('UNIT_TESTS_OK', rule='TP_PARTIAL stays occupied; grid math OK')

def initial_state():
    pos=A.positions(); pending=A.pending()
    if any(D(p.get('pos'))!=0 for p in pos) or pending:
        die('Untracked ETH positions/orders. Refusing to initialize.')
    st={'version':VER,'instrument':INST,'cycles':{},'completed':0,'bootstrapped':True}
    save(st); return st

def verify_existing(st,pending):
    # Under a net-mode account, any outside ETH trading invalidates our ledger.
    known_ids={x.get('ordId') for x in st['cycles'].values() if x.get('ordId')}
    known_tp_ids={x.get('tpOrdId') for x in st['cycles'].values() if x.get('tpOrdId')}
    known_tp_client_ids={x.get('tpClOrdId') for x in st['cycles'].values() if x.get('tpClOrdId')}
    unknown=[o for o in pending if o.get('ordId') not in known_ids|known_tp_ids
             and not (o.get('side')=='sell' and (
                 o.get('clOrdId') in known_tp_client_ids or
                 o.get('algoClOrdId') in known_tp_client_ids))]
    if unknown:
        die('Unrecognized open order(s): '+','.join(o.get('ordId','?') for o in unknown[:5]))

def track(st, pending):
    """Reconcile every cycle using real BUY/SELL order IDs.

    Attached LIMIT TP is a regular SELL once activated, NOT necessarily an
    accessible algo order. Client ID given in attachAlgoClOrdId is propagated
    to the resulting SELL (verified on OKX private orders WS).
    Return False on transient TP synchronization; callers MUST NOT place BUYs.
    """
    all_resolved = True
    # One exchange snapshot instead of a REST GET for every still-live order.
    # On a large grid, querying hundreds of unchanged orders sequentially
    # would delay decisions during a fast move and hit rate limits.
    pending_by_id = {o.get('ordId'): o for o in pending}
    for key, x in list(st['cycles'].items()):
        status = x['state']
        if status in ('CLOSED', 'CANCELED'):
            continue
        if status == 'PLACING':
            o = A.order(cid=x['clOrdId'])
            if not o:
                die('Uncertain BUY placement '+x['clOrdId']+'; manual reconciliation')
            x['ordId']=o['ordId']; x['state']='BUY_LIVE'; save(st)
            status='BUY_LIVE'
        if status == 'CANCELING':
            o=A.order(oid=x['ordId'])
            if not o: die('Cannot confirm cancellation at '+key)
            if o.get('state')=='canceled' and D(o.get('accFillSz'))==0:
                x['state']='CANCELED';save(st);continue
            die('Ambiguous BUY cancellation with possible fill at '+key)
        if status in ('BUY_LIVE', 'BUY_PARTIAL'):
            o=pending_by_id.get(x['ordId']) or A.order(oid=x['ordId'])
            if not o: die('BUY unavailable: '+x['ordId']+'; manual reconciliation')
            state=o.get('state'); filled=D(o.get('accFillSz'))
            if state=='filled':
                x['state']='TP_WAIT';x['filledBuy']=str(filled);save(st)
                log('BUY_FILLED',price=key,ordId=x['ordId'],tp=x['tpPx'])
            elif state=='partially_filled':
                x['state']='BUY_PARTIAL';x['filledBuy']=str(filled);save(st)
            elif state=='live':
                if status!='BUY_LIVE': x['state']='BUY_LIVE';save(st)
            elif state in ('canceled','mmp_canceled'):
                if filled: die('BUY canceled after partial execution at '+key)
                x['state']='CANCELED';save(st)
                log('BUY_CANCELED',price=key)
                continue
            else: die('Unknown BUY state '+str(state))

        if x['state'] not in ('TP_WAIT', 'TP_PARTIAL'):
            continue
        cid=x['tpClOrdId']
        tp_id=x.get('tpOrdId','')
        t=None
        matching_pending=[o for o in pending if o.get('side')=='sell' and (
            o.get('clOrdId')==cid or o.get('algoClOrdId')==cid)]
        if len(matching_pending)>1:
            die('Multiple active TP orders with same client ID at '+key)
        if tp_id:
            # The exchange's active-order snapshot is authoritative for live TP.
            t=next((o for o in matching_pending if o.get('ordId')==tp_id),None)
            if t is None: t=A.order(oid=tp_id)
        else:
            if matching_pending:
                t=matching_pending[0]
            else:
                # Try ordinary SELL, not /trade/order-algo. LIMIT TP produces a
                # regular order, and /order-algo may return 51603.
                t=A.order(cid=cid)
                if t is None:
                    hist=[o for o in A.history() if o.get('side')=='sell' and (
                        o.get('clOrdId')==cid or o.get('algoClOrdId')==cid)]
                    if len(hist)>1: die('Ambiguous historical TP at '+key)
                    if hist: t=hist[0]
            if t:
                tp_id=t.get('ordId','')
                if not tp_id: die('TP with missing exchange order ID '+key)
                x['tpOrdId']=tp_id;save(st)
                log('TP_LINKED',price=key,tpOrdId=tp_id,clOrdId=cid)

        if t is None:
            # An unmatched TP is dangerous: hold the level and stop new BUYs.
            if 'tpMissingSince' not in x:
                x['tpMissingSince']=time.time()
                save(st)
            first=x['tpMissingSince']
            if time.time()-first > 60:
                die('TP still not queryable after 60s at '+key+
                    '; verify SELL and position manually (no new orders)')
            all_resolved=False
            continue
        if x.pop('tpMissingSince',None) is not None: save(st)
        if t.get('instId')!=INST or t.get('side')!='sell':
            die('TP instrument/side mismatch at '+key)
        # Verify true identity; do not match a random SELL by size and price.
        if t.get('clOrdId') != cid and t.get('algoClOrdId') != cid:
            die('TP client ID mismatch at '+key)
        if D(t.get('sz'))!=D(x.get('filledBuy')):
            die('TP total quantity mismatch at '+key)
        if D(t.get('px'))!=D(x.get('tpPx')):
            die('TP price mismatch at '+key)
        tstate=t.get('state')
        filled_tp=D(t.get('accFillSz'))
        if filled_tp > D(x['filledBuy']):
            die('TP filled more than BUY at '+key)
        if x.get('filledTP')!=str(filled_tp):
            x['filledTP']=str(filled_tp);save(st)
        if tstate=='filled' and filled_tp==D(x['filledBuy']):
            x['state']='CLOSED';st['completed']+=1;save(st)
            log('TP_FILLED',price=key,tpId=tp_id)
        elif tstate=='partially_filled':
            if x['state']!='TP_PARTIAL':
                x['state']='TP_PARTIAL';save(st)
                log('TP_PARTIAL',price=key,filled=str(filled_tp),total=x['filledBuy'])
        elif tstate in ('canceled','mmp_canceled'):
            die('TP canceled, unclosed exposure at '+key+'; manual review')
        elif tstate=='filled':
            die('TP filled with wrong volume at '+key)
        elif tstate!='live':
            die('Unknown TP order status '+str(tstate))
    return all_resolved

def place(st,px):
    k=fmt(px); tp=fmt(px+TP)
    previous=st['cycles'].get(k)
    if previous:
        if previous['state'] not in ('CLOSED','CANCELED'):
            die('Level already occupied: '+k)
        st.setdefault('archived_cycles',[]).append({'level':k,**previous})
        save(st)
    cl=newid('B'); tcl=newid('T')
    x={'state':'PLACING','buyPx':k,'tpPx':tp,'sz':str(QTY),
       'clOrdId':cl,'tpClOrdId':tcl,'ordId':'','tpOrdId':''}
    st['cycles'][k]=x; save(st)  # durable intent BEFORE network request
    req={'instId':INST,'tdMode':'cross','side':'buy','posSide':'net',
         'ordType':'post_only','px':k,'sz':str(QTY),'clOrdId':cl,
         'attachAlgoOrds':[{'attachAlgoClOrdId':tcl,'tpOrdKind':'limit','tpOrdPx':tp}]}
    data=A.req('POST','/api/v5/trade/order',body=req)
    if len(data)!=1:
        die('Unexpected place-order response: '+str(data))
    if data[0].get('sCode') != '0':
        # Positive OKX rejection acknowledgement: no order was placed.
        x['state']='CANCELED'; x['rejectCode']=data[0].get('sCode'); save(st)
        log('BUY_REJECTED',price=k,code=x['rejectCode'],msg=data[0].get('sMsg',''))
        # Recalculate on next market snapshot; don't blindly resend here.
        return False
    if not data[0].get('ordId'):
        die('Order accepted without ID: manual check required')
    x['ordId']=data[0]['ordId']; x['state']='BUY_LIVE'; save(st)
    log('BUY_PLACED',price=k,tp=tp,ordId=x['ordId'])
    return True

def cancel_lowest_specific(st,lowest):
    oid=lowest['ordId']
    # Durable intent, same discipline as placing orders.
    lowest['state']='CANCELING'; save(st)
    data=A.req('POST','/api/v5/trade/cancel-order',body={'instId':INST,'ordId':oid})
    if len(data)!=1 or data[0].get('sCode')!='0':
        die('Cancellation not accepted: '+str(data))
    o=A.order(oid=oid)
    if not o or o.get('state') not in ('canceled','filled','partially_filled'):
        die('Cancellation not yet final; STOP until verified')
    if D(o.get('accFillSz'))>0:
        die('BUY filled during cancellation: manual review required')
    if o.get('state')!='canceled':
        die('BUY cancellation did not complete')
    lowest['state']='CANCELED'; save(st)
    log('BUY_MOVED_UP',cancelled=lowest['buyPx'],ordId=oid)
    return True

class WSWatcher(threading.Thread):
    """Private order event stream; REST remains the authority for reconciliation."""
    def __init__(self):
        super().__init__(daemon=True)
        self.events=queue.Queue(maxsize=1000)
        self.wake=threading.Event()
        self.connected=False
    def run(self):
        while True:
            ws=None
            try:
                ws=websocket.create_connection('wss://ws.okx.com/ws/v5/private',
                    timeout=12,header=['User-Agent: curl/8.5.0'])
                ts=str(int(time.time()))
                msg=ts+'GET/users/self/verify'
                sig=base64.b64encode(hmac.new(ENV['OKX_API_SECRET'].encode(),
                    msg.encode(),hashlib.sha256).digest()).decode()
                ws.send(json.dumps({'op':'login','args':[{'apiKey':ENV['OKX_API_KEY'],
                    'passphrase':ENV['OKX_API_PASSPHRASE'],'timestamp':ts,'sign':sig}]}))
                ans=json.loads(ws.recv())
                if ans.get('event')!='login' or ans.get('code')!='0': die('WS login '+str(ans))
                ws.send(json.dumps({'op':'subscribe','args':[{'channel':'orders',
                    'instType':'SWAP','instId':INST}]}))
                ans=json.loads(ws.recv())
                if ans.get('event')!='subscribe': die('WS subscribe '+str(ans))
                self.connected=True
                ws.settimeout(5); last_ping=time.monotonic()
                while True:
                    if time.monotonic()-last_ping>=15:
                        ws.send('ping');last_ping=time.monotonic()
                    try: raw=ws.recv()
                    except websocket.WebSocketTimeoutException: continue
                    if raw=='ping': ws.send('pong');continue
                    if raw=='pong':continue
                    parsed=json.loads(raw)
                    if parsed.get('event')=='error': die('WS event error '+str(parsed))
                    if parsed.get('arg',{}).get('channel')=='orders':
                        for item in parsed.get('data',[]):
                            if item.get('instId')==INST:
                                safe={k:item.get(k) for k in ('ordId','clOrdId','algoClOrdId',
                                    'side','state','accFillSz','fillSz','tradeId')}
                                self.events.put_nowait(safe)
                                self.wake.set()
            except Exception as e:
                self.connected=False
                # Never log authentication messages containing credentials.
                print('[WS] reconnect in 5s:',type(e).__name__,flush=True)
                time.sleep(5)
            finally:
                self.connected=False
                if ws:
                    try: ws.close()
                    except Exception: pass


class PublicBidWatcher(threading.Thread):
    """Realtime OKX BID feed. Never sends private credentials.

    The ticker channel pushes a snapshot on price/best-bid changes (fastest
    published update period 100ms). REST is used if WS is disconnected or
    has not received an update for a while. A stale cached quote is NEVER used
    for placing/canceling live orders.
    """
    def __init__(self):
        super().__init__(daemon=True)
        self._lock=threading.Lock()
        self._bid=None
        self._updated=0.0
        self.connected=False
        self.wake=threading.Event()
        self.fallback_logged=False

    def run(self):
        while True:
            ws=None
            try:
                ws=websocket.create_connection('wss://ws.okx.com/ws/v5/public',
                    timeout=12,header=['User-Agent: curl/8.5.0'])
                ws.send(json.dumps({'op':'subscribe','args':[
                    {'channel':'tickers','instId':INST}]}))
                reply=json.loads(ws.recv())
                if reply.get('event') != 'subscribe':
                    die('Public BID subscription failed: '+str(reply))
                self.connected=True
                print('✅ Public BID WebSocket connected',flush=True)
                ws.settimeout(3)
                last_ping=time.monotonic()
                while True:
                    if time.monotonic()-last_ping >= 15:
                        ws.send('ping')
                        last_ping=time.monotonic()
                    try:
                        raw=ws.recv()
                    except websocket.WebSocketTimeoutException:
                        continue
                    if raw=='ping': ws.send('pong'); continue
                    if raw=='pong': continue
                    msg=json.loads(raw)
                    if msg.get('event')=='error': die('Public BID WS error '+str(msg))
                    if msg.get('arg',{}).get('channel')!='tickers':
                        continue
                    for data in msg.get('data',[]):
                        if data.get('instId')!=INST: continue
                        bid=D(data.get('bidPx'))
                        if bid<=0: continue
                        with self._lock:
                            self._bid=bid
                            self._updated=time.monotonic()
                        self.wake.set()
            except Exception as e:
                print('[BID WS] reconnect in 5s:',type(e).__name__,flush=True)
                time.sleep(5)
            finally:
                self.connected=False
                with self._lock:
                    self._updated=0.0
                if ws:
                    try: ws.close()
                    except Exception: pass

    def get_bid(self):
        with self._lock:
            cached=self._bid
            age=time.monotonic()-self._updated
        if self.connected and cached is not None and age<=3.0:
            self.fallback_logged=False
            return cached
        # When an instrument stays unchanged the channel need not publish;
        # verify the quote with REST instead of assuming the old WS bid is fresh.
        if not self.fallback_logged:
            log('BID_REST_FALLBACK',reason='WS disconnected or quote >3s old')
            self.fallback_logged=True
        return A.ticker()


def grid_top(bid):
    top=(bid/STEP).to_integral_value(rounding=ROUND_FLOOR)*STEP
    if top>=bid: top-=STEP
    return top


def desired_buy_levels(top,occupied_tp):
    wanted=set()
    price=top
    while len(wanted)<TARGET and price>0:
        if price not in occupied_tp: wanted.add(price)
        price-=STEP
    if len(wanted)<TARGET: die('Insufficient valid grid levels')
    return wanted


class PnLWorker(threading.Thread):
    """Calculate real fill fees in background, NEVER delay trading on PnL I/O."""
    def __init__(self,pnl):
        super().__init__(daemon=True)
        self.pnl=pnl
        self.jobs=queue.Queue(maxsize=1)

    def submit(self,st):
        # Main thread alone owns/mutates trading state; the copy is immutable
        # to the worker and skips a file write if there are no closed cycles.
        if not any(x.get('state')=='CLOSED'
                   for x in list(st['cycles'].values())+st.get('archived_cycles',[])):
            return
        try: self.jobs.put_nowait(copy.deepcopy(st))
        except queue.Full: pass  # Next pass will submit a newer snapshot.

    def run(self):
        while True:
            state=self.jobs.get()
            try:
                self.pnl.work(state,max_cycles=2,historical=False)
            except Exception as e:
                print('⚠️ PnL background error:',type(e).__name__,str(e)[:140],flush=True)


def acquire_lock():
    path=ROOT/'state'/'bot05.lock'
    fd=os.open(path,os.O_CREAT|os.O_RDWR,0o600)
    try:
        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        os.close(fd)
        die('Another OKX bot05 instance is already running. STOP it first.')
    return fd


def ensure_state():
    if DATA.exists():
        st=json.loads(DATA.read_text())
        if st.get('instrument') != INST: die('Wrong state instrument')
        previous_version=st.get('version')
        if previous_version in ('0.4.1','0.5.0','0.5.1','0.5.2','0.5.3','0.5.4'):
            backup=DATA.with_name('bot04_state_before_v055.json')
            if not backup.exists():
                shutil.copy2(DATA,backup)
                os.chmod(backup,0o600)
            st['version']=VER
            st.setdefault('archived_cycles',[])
            save(st)
            log('STATE_UPGRADED',from_version=previous_version,to_version=VER,
                preserved_cycles=len(st['cycles']))
        elif previous_version != VER:
            die('Unsupported old state version: '+str(previous_version))
        return st
    if not LIVE:
        return {'cycles':{},'completed':0,'version':VER,'instrument':INST}
    return initial_state()


def reconcile_position(st, timeout=30, pause=1):
    """Read *fresh* order states and net position until they agree.

    Under rapid multiple fills a sequential GET /trade/order pass is not an
    atomic snapshot: later orders can fill AFTER we queried them, but BEFORE
    /account/positions. An immediate mismatch isn't proof of missing trades.
    NEVER submit new orders until a complete fresh pass reconciles. If the
    mismatch persists beyond the timeout, fail closed with existing orders
    still on the exchange.
    """
    started=time.monotonic()
    previous=None
    while True:
        pending=A.pending()
        resolved=track(st,pending)
        verify_existing(st,pending)
        positions=A.positions()
        expected=sum((D(x.get('filledBuy'))-D(x.get('filledTP'))
                      for x in st['cycles'].values()), Decimal('0'))
        actual=sum((D(p.get('pos')) for p in positions),Decimal('0'))
        if actual==expected:
            if previous is not None:
                log('POSITION_SYNC_OK',exchange=str(actual),local=str(expected),
                    retries=previous)
            return pending,resolved,actual
        remaining=timeout-(time.monotonic()-started)
        if remaining <= 0:
            die('Position mismatch persisted after full REST rechecks: '
                f'exchange={actual} local={expected}; no new BUY. '
                'Inspect pending orders and position before restarting.')
        # Expose the mismatch, rather than making a trading decision with
        # data from different moments in time.
        if previous is None:
            previous=0
        previous+=1
        if previous==1 or previous%5==0:
            log('POSITION_SYNC_WAIT',exchange=str(actual),local=str(expected),
                retry=previous,timeout_seconds=timeout)
        time.sleep(min(pause,max(0.1,remaining)))


def audit_once(st):
    pending,resolved,actual=reconcile_position(st,timeout=30)
    states={}
    for c in st['cycles'].values():
        states[c['state']]=states.get(c['state'],0)+1
    buys=sum(o.get('side')=='buy' for o in pending)
    sells=sum(o.get('side')=='sell' for o in pending)
    print('=== READ ONLY AUDIT ===',flush=True)
    print('Position (contracts):',str(actual),flush=True)
    print('Open BUY:',buys,'Open SELL TP:',sells,flush=True)
    print('Tracked states:',json.dumps(states,sort_keys=True),flush=True)
    print('TP links resolved:',resolved,flush=True)
    if not resolved:
        die('Not all attached TPs resolved. No trading permitted.')
    print('✅ AUDIT OK — NO ORDERS SUBMITTED OR CANCELED',flush=True)


def live_loop(st,watcher,market,pnl,pnl_worker):
    last_status_key=None
    last_print=0
    while True:
        started=time.monotonic()
        # Private WS acts as a wake signal; only REST-synchronized states may
        # cause order placement or rearming. Drop duplicate messages safely.
        while not watcher.events.empty():
            log('WS_ORDER',**watcher.events.get_nowait())
        watcher.wake.clear()

        pending,all_resolved,actual=reconcile_position(st,timeout=30)
        if all_resolved:
            pnl_worker.submit(st)
        if not all_resolved:
            print('WAIT_TP_SYNC: no new BUY until attached SELL is verified',flush=True)
            time.sleep(INTERVAL)
            continue

        bid=market.get_bid()
        top=grid_top(bid)
        active=active_buy(st)
        if len(active)>TARGET: die('More than 20 active BUYs')

        # Catch up with a large upward jump *in this pass*, not one BUY every
        # 5+ seconds. Cancel at most 20 individually, confirming each cancel.
        # An order that fills while cancellation is pending causes fail-stop.
        moved=0
        if LIVE and len(active)>=TARGET:
            while moved < TARGET:
                fresh_bid=market.get_bid()
                fresh_top=grid_top(fresh_bid)
                active=active_buy(st)
                if not active: break
                occupied_tp={D(k) for k,x in st['cycles'].items()
                    if x['state'] in ('TP_WAIT','TP_PARTIAL')}
                desired=desired_buy_levels(fresh_top,occupied_tp)
                active_prices={D(x['buyPx']) for x in active}
                if not active_prices or fresh_top<max(active_prices): break
                obsolete=[x for x in active if D(x['buyPx']) not in desired
                          and x['state']=='BUY_LIVE']
                if not obsolete: break
                cancel_lowest_specific(st,min(obsolete,key=lambda x:D(x['buyPx'])))
                moved+=1
            if moved:
                # Cancelling is not a globally atomic snapshot. Reconcile all
                # fills/TPs before submitting replacement BUYs.
                pending,all_resolved,actual=reconcile_position(st,timeout=30)
                if not all_resolved:
                    print('WAIT_TP_SYNC after BUY rebalance',flush=True)
                    time.sleep(INTERVAL)
                    continue
                bid=market.get_bid()
                top=grid_top(bid)
                active=active_buy(st)

        cap=max(0,min(TARGET-len(active),CAP-count(st),EX_CAP-len(pending)))
        candidates=[]
        price=top
        while len(candidates)<cap and price>0:
            if level_free(st,price): candidates.append(price)
            price-=STEP
        if not LIVE:
            print('DRY RUN', 'BID',bid,'current BUY',len(active),
                  'occupied',count(st),'would place',
                  [(fmt(p),fmt(p+TP)) for p in candidates],flush=True)
            break

        placed=0
        for price in candidates:
            if not level_free(st,price): continue
            if len(active_buy(st))>=TARGET or count(st)>=CAP: break
            # Under a fast fall the planned bid can become marketable.
            # POST_ONLY would reject it, but stop the stale batch earlier.
            if price>=market.get_bid():
                log('BUY_BATCH_PAUSED',reason='BID moved below planned level',
                    level=fmt(price))
                break
            if place(st,price): placed+=1
            else: break
            time.sleep(0.10)

        states={}
        for c in st['cycles'].values():
            states[c['state']]=states.get(c['state'],0)+1
        tps=states.get('TP_WAIT',0)+states.get('TP_PARTIAL',0)
        status=(f'BID={bid} | BUY {len(active_buy(st))}/{TARGET} '
                f'| TP {tps} | гриды {count(st)}/{CAP} '
                f'| закрыто {st["completed"]} | {pnl.status(st)}')
        now=time.monotonic()
        status_key=(len(active_buy(st)),tps,count(st),st['completed'],pnl.status(st))
        if status_key!=last_status_key or placed or moved or now-last_print>=60:
            print('📊 '+status,flush=True)
            last_status_key=status_key; last_print=now
        # Keep the safety loop at ~1s maximum idle delay. During REST work,
        # processing can still be slower; never promise a fixed 1s reaction.
        delay=max(0.0, INTERVAL-(time.monotonic()-started))
        if delay:
            watcher.wake.wait(delay)
            watcher.wake.clear()



# Full WEEX-style statistics, independent of the trading reconciliation thread.
# All numbers are derived from OKX's actual fills (not LIMIT prices).
STATS_INTERVAL = 600  # print immediately at start, then every ten minutes
STATS_HISTORY_PAGES_LIMIT = 200  # cap REST work and disclose if coverage fails
STATS_INTERVAL_BETWEEN_PAGES = 0.23  # OKX fills-history: 10 requests / 2s


def stats_pct(num, denominator):
    if denominator <= 0:
        return '—'
    pct=num / denominator * Decimal(100)
    return f'{pct:.6f}%' if pct and abs(pct)<Decimal('0.01') else f'{pct:.4f}%' 


def stats_amount(x, digits=6):
    return f'${x:,.{digits}f}'


def full_stats_snapshot(state, fills, bid, contract_value):
    """Pure calculation over authoritative fill rows.

    Financial statistics are complete only if *every* expected BUY/TP fill
    for every tracked cycle is present. Partial history is NEVER represented
    as full lifetime accounting.
    """
    cycles=list(state.get('cycles',{}).values())+state.get('archived_cycles',[])
    grouped={}
    # idempotent even if API pagination boundaries overlap
    seen=set()
    unique_fills=[]
    for f in fills:
        oid=str(f.get('ordId') or '')
        tid=str(f.get('tradeId') or '')
        bill=str(f.get('billId') or '')
        if not oid or not tid or not bill: raise ValueError('Fill missing identifying fields')
        identity=(oid,bill)
        if identity in seen: continue
        seen.add(identity)
        unique_fills.append(f)
        if f.get('fee') in (None,''):
            raise ValueError('Missing actual fee; no estimate allowed')
        if f.get('feeCcy')!='USDT':
            raise ValueError('Non-USDT fee currency; cannot report exact USDT fees')
        if f.get('execType') not in ('M','T'):
            raise ValueError('Unknown Maker/Taker execution type')
        px=D(f['fillPx']); quantity=D(f['fillSz'])
        if px<=0 or quantity<=0: raise ValueError('Invalid fill size/price')
        g=grouped.setdefault(oid,{'qty':Decimal(0),'notional':Decimal(0),
                                   'fee':Decimal(0),'side':f.get('side')})
        if g['side'] != f.get('side'):
            raise ValueError('Mixed BUY/SELL under same ordId')
        g['qty']+=quantity
        g['notional']+=quantity*contract_value*px
        g['fee']+=D(f['fee'])

    closed_count=0
    closed_gain=Decimal(0)
    closed_buy_nominal=Decimal(0)
    open_gain=Decimal(0)
    open_buy_nominal=Decimal(0)
    expected={}
    known_orders=set()
    for c in cycles:
        buy_id=str(c.get('ordId') or '')
        sell_id=str(c.get('tpOrdId') or '')
        buy_sz=D(c.get('filledBuy'))
        sell_sz=D(c.get('filledTP'))
        if buy_sz:
            if not buy_id: raise ValueError('Missing BUY order ID for filled quantity')
            expected[buy_id]=buy_sz
            known_orders.add(buy_id)
        if sell_sz:
            if not sell_id: raise ValueError('Missing TP order ID for filled quantity')
            expected[sell_id]=sell_sz
            known_orders.add(sell_id)

    missing=[(oid,qty,grouped.get(oid,{}).get('qty',Decimal(0)))
             for oid,qty in expected.items()
             if grouped.get(oid,{}).get('qty',Decimal(0)) != qty]
    if missing:
        return {'complete':False,'missing':missing[:4],
                'fill_orders_expected':len(expected),'fill_orders_seen':len(grouped)}

    maker_volume=taker_volume=maker_fee=taker_fee=Decimal(0)
    for f in unique_fills:
        oid=str(f.get('ordId') or '')
        if oid not in known_orders: continue
        px=D(f['fillPx']); qty=D(f['fillSz']); fee=D(f['fee'])
        if f['execType']=='M': maker_volume+=qty*contract_value*px;maker_fee+=fee
        elif f['execType']=='T': taker_volume+=qty*contract_value*px;taker_fee+=fee

    for c in cycles:
        b=grouped.get(str(c.get('ordId') or ''),None)
        s=grouped.get(str(c.get('tpOrdId') or ''),None)
        if not b or b['qty']<=0: continue
        buy_avg=b['notional']/(b['qty']*contract_value)
        sell_qty=s['qty'] if s else Decimal(0)
        if sell_qty>b['qty']: raise ValueError('TP exceeds BUY')
        sell_nominal=s['notional'] if s else Decimal(0)
        sell_fee=s['fee'] if s else Decimal(0)
        remaining=b['qty']-sell_qty
        if c.get('state')=='CLOSED':
            if remaining: raise ValueError('CLOSED cycle has unclosed position')
            closed_count+=1
            closed_gain += sell_nominal-b['notional']+b['fee']+sell_fee
            closed_buy_nominal+=b['notional']
        else:
            # Open-cycle mark-to-market, including realized portion of PARTIAL
            # TP and commissions already paid. Funding excluded.
            open_gain += (sell_nominal - sell_qty*contract_value*buy_avg +
                          remaining*contract_value*(bid-buy_avg) +
                          b['fee'] + sell_fee)
            open_buy_nominal+=b['notional']

    volume=maker_volume+taker_volume
    total_fees=maker_fee+taker_fee
    total_gain=closed_gain+open_gain
    total_buy=closed_buy_nominal+open_buy_nominal
    active_buys=sum(c.get('state') in ('BUY_LIVE','BUY_PARTIAL','PLACING') for c in state.get('cycles',{}).values())
    tps=sum(c.get('state') in ('TP_WAIT','TP_PARTIAL') for c in state.get('cycles',{}).values())
    open_contracts=sum((D(c.get('filledBuy'))-D(c.get('filledTP'))
                        for c in state.get('cycles',{}).values()),Decimal(0))
    return dict(complete=True,bid=bid,closed_count=closed_count,
                active_buys=active_buys,tps=tps,grid_gain=closed_gain,
                grid_pct=stats_pct(closed_gain,closed_buy_nominal),
                open_gain=open_gain,open_pct=stats_pct(open_gain,open_buy_nominal),
                total_gain=total_gain,total_pct=stats_pct(total_gain,total_buy),
                total_fees=total_fees,volume=volume,maker_volume=maker_volume,
                taker_volume=taker_volume,maker_fee=maker_fee,taker_fee=taker_fee,
                maker_percent=stats_pct(maker_volume,volume),
                taker_percent=stats_pct(taker_volume,volume),
                maker_fee_pct=stats_pct(-maker_fee,maker_volume),
                taker_fee_pct=stats_pct(-taker_fee,taker_volume),
                open_contracts=open_contracts,open_eth=open_contracts*contract_value,
                account_closed=state.get('completed',0),
                expected_orders=len(expected))


def stats_exchange_fills(state):
    cycles=list(state.get('cycles',{}).values())+state.get('archived_cycles',[])
    expected={}
    for c in cycles:
        if D(c.get('filledBuy'))>0 and c.get('ordId'):
            expected[str(c['ordId'])]=D(c['filledBuy'])
        if D(c.get('filledTP'))>0 and c.get('tpOrdId'):
            expected[str(c['tpOrdId'])]=D(c['filledTP'])
    if not expected:
        return []
    got={}
    rows=[]; seen_bills=set(); after=None
    for page_number in range(STATS_HISTORY_PAGES_LIMIT):
        params={'instType':'SWAP','instId':INST,'limit':'100'}
        if after: params['after']=after
        page=A.req('GET','/api/v5/trade/fills-history',params)
        for f in page:
            oid=str(f.get('ordId') or '')
            bill=str(f.get('billId') or '')
            if oid not in expected or not bill or bill in seen_bills:continue
            seen_bills.add(bill)
            got[oid]=got.get(oid,Decimal(0))+D(f.get('fillSz'))
            rows.append(f)
        if all(got.get(oid,Decimal(0))==q for oid,q in expected.items()):
            return rows
        if len(page)<100: return rows
        nxt=str(page[-1].get('billId') or '')
        if not nxt or nxt==after: raise RuntimeError('Fills pagination stalled')
        after=nxt
        time.sleep(STATS_INTERVAL_BETWEEN_PAGES)
    raise RuntimeError('Too many historical pages; stats coverage not verified')


def print_full_stats():
    """Safe standalone read: cannot submit or cancel an OKX order."""
    if not DATA.exists():
        print('📊 GRID STATISTICS: торговое состояние ещё не создано',flush=True)
        return
    st=json.loads(DATA.read_text())
    if st.get('instrument')!=INST:
        raise ValueError('Statistics file is not for ETH-USDT-SWAP')
    # Fetching the BID for valuation is read-only; will not affect trading.
    bid=A.ticker()
    fills=stats_exchange_fills(st)
    d=full_stats_snapshot(st,fills,bid,CONTRACT_VALUE)
    print('\n════════ OKX ETH GRID STATISTICS ════════',flush=True)
    print('  BID:',f'{bid:.2f}',flush=True)
    if not d['complete']:
        print('  ⚠️ Статистика неполная: часть исполнений отсутствует',flush=True)
        print('  Исполнения для ордеров:',d['fill_orders_seen'],'/',d['fill_orders_expected'],flush=True)
        print('  Примеры расхождений:',d['missing'],flush=True)
        print('  Финансовые суммы не выводятся, чтобы не искажать результат.',flush=True)
        print('══════════════════════════════════════════\n',flush=True)
        return
    print('  Закрытых циклов:',d['closed_count'],flush=True)
    print(f"  Активные: BUY LIMIT {d['active_buys']} | WAIT_TP {d['tps']}",flush=True)
    print('  GRID PROFIT:',money_usdt(d['grid_gain']),f"({d['grid_pct']})",flush=True)
    print('  Комиссии:',stats_amount(-d['total_fees']),flush=True)
    print('  Общий объём BUY+SELL:',stats_amount(d['volume'],4),flush=True)
    print(f"  Maker: {stats_amount(d['maker_volume'],4)} ({d['maker_percent']}) | "
          f"комиссия {stats_amount(-d['maker_fee'])} ({d['maker_fee_pct']})",flush=True)
    print(f"  Taker: {stats_amount(d['taker_volume'],4)} ({d['taker_percent']}) | "
          f"комиссия {stats_amount(-d['taker_fee'])} ({d['taker_fee_pct']})",flush=True)
    print('  Открытая позиция:',f"{d['open_eth']} ETH / {d['open_contracts']} контрактов",flush=True)
    print('  Unrealized PnL:',money_usdt(d['open_gain']),f"({d['open_pct']})",flush=True)
    print('  ИТОГОВЫЙ PnL:',bold(money_usdt(d['total_gain'])),f"({d['total_pct']})",flush=True)
    print('  % к номиналу исполненных BUY, НЕ доходность на маржу',flush=True)
    print('  Open PnL — оценка открытых циклов по BID, с уже списанными комиссиями',flush=True)
    print('  Funding не включён',flush=True)
    print('  ✅ Все известные исполнения сопоставлены',flush=True)
    print('══════════════════════════════════════════\n',flush=True)


class StatsWorker(threading.Thread):
    """Independent read-only stats. Never blocks or modifies order management."""
    def __init__(self):
        super().__init__(daemon=True)

    def run(self):
        while True:
            try:
                print_full_stats()
            except Exception as e:
                print('⚠️ Статистика недоступна:',type(e).__name__,str(e)[:180],flush=True)
            time.sleep(STATS_INTERVAL)


def main():
    if STATS_ONLY:
        print_full_stats()  # read-only, no lock, safe while LIVE bot runs
        return
    lock=acquire_lock()
    try:
        print(f'=== OKX BOT01 v{VER} ===',
              'LIVE 20 BUY' if LIVE else ('READ ONLY AUDIT' if AUDIT else 'READ ONLY'),flush=True)
        run_tests()
        a=A.req('GET','/api/v5/account/config')
        if not a or a[0].get('posMode')!='net_mode': die('Only net_mode supported')
        info=A.instrument()
        value=D(info.get('ctVal'))
        if info.get('ctValCcy')!='ETH' or value!=CONTRACT_VALUE:
            die('Unexpected ETH contract value. STOP for safe PnL calculation.')
        st=ensure_state()
        pnl=PnLLedger(value)
        pnl.initial_ids={pnl.identity(c) for c in pnl.all_cycles(st)}
        log('START',live=LIVE,audit=AUDIT,tracked=count(st),
            realized_usdt=str(pnl.total()))
        if AUDIT:
            audit_once(st)
            pnl.work(st,max_cycles=1,historical=True)
            print('💰',pnl.status(st),flush=True)
            try: print_full_stats()
            except Exception as e:
                print('⚠️ Статистика недоступна:',type(e).__name__,str(e)[:180],flush=True)
            return
        watcher=WSWatcher();watcher.start()
        market=PublicBidWatcher();market.start()
        pnl_worker=PnLWorker(pnl);pnl_worker.start()
        stats_worker=StatsWorker();stats_worker.start()
        live_loop(st,watcher,market,pnl,pnl_worker)
    finally:
        os.close(lock)

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt: print('\nStopped (open orders remain on OKX).',flush=True)
    except Exception as exc:
        print('⛔ STOP:',str(exc),file=sys.stderr,flush=True)
        sys.exit(1)
