import os
import json
import hmac
import base64
import hashlib
import urllib.request
import urllib.error
from datetime import datetime, timezone

# Load credentials
env = {}
with open(".env") as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        env[k.strip()] = v.strip().strip('"').strip("'")

KEY = env.get("OKX_API_KEY", "")
SECRET = env.get("OKX_API_SECRET", "")
PASS = env.get("OKX_API_PASSPHRASE", "")
DEMO = env.get("OKX_DEMO", "0") == "1"

if not all([KEY, SECRET, PASS]):
    raise SystemExit("ERROR: Missing API credentials in .env")

BASE = "https://www.okx.com"

def check(name, path, private=True):
    headers = {"Content-Type": "application/json", "User-Agent": "curl/8.5.0"}

    if private:
        ts = datetime.now(timezone.utc).isoformat(
            timespec="milliseconds"
        ).replace("+00:00", "Z")

        msg = ts + "GET" + path
        sign = base64.b64encode(
            hmac.new(
                SECRET.encode(),
                msg.encode(),
                hashlib.sha256
            ).digest()
        ).decode()

        headers.update({
            "OK-ACCESS-KEY": KEY,
            "OK-ACCESS-SIGN": sign,
            "OK-ACCESS-TIMESTAMP": ts,
            "OK-ACCESS-PASSPHRASE": PASS
        })

    if DEMO:
        headers["x-simulated-trading"] = "1"

    req = urllib.request.Request(BASE + path, headers=headers)

    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            result = json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            result = json.loads(e.read())
        except Exception:
            result = {"code": str(e.code), "msg": e.reason}
    except Exception as e:
        print(f"❌ {name}: {type(e).__name__}: {e}")
        return

    if result.get("code") == "0":
        print(f"✅ {name}: OK")
        data = result.get("data", [])

        if name == "ACCOUNT" and data:
            a = data[0]
            print("   Account level:", a.get("acctLv"))
            print("   Position mode:", a.get("posMode"))
            print("   API permissions:", a.get("perm"))

        if name == "ORDERS":
            print("   Open orders:", len(data))

    else:
        print(f"❌ {name}: FAILED")
        print("   Code:", result.get("code"))
        print("   Message:", result.get("msg"))

print("\n=== OKX API CONNECTION TEST ===")
print("Mode:", "DEMO" if DEMO else "LIVE")
print()

check("SERVER TIME", "/api/v5/public/time", False)
check("ACCOUNT", "/api/v5/account/config")
check("BALANCE", "/api/v5/account/balance")
check("ORDERS", "/api/v5/trade/orders-pending")

print("\n=== TEST COMPLETE ===")
