import json
from decimal import Decimal, ROUND_FLOOR
import websocket

VERSION = "0.1.0"

with open("config.json") as f:
    cfg = json.load(f)

if cfg["live_trading"]:
    raise SystemExit("STOP: This version supports DRY RUN only")

INST = cfg["instrument"]
STEP = Decimal(cfg["grid_step"])
TP = Decimal(cfg["take_profit"])
QTY = Decimal(cfg["order_size"])
ACTIVE = int(cfg["active_buy_orders"])
MAX_GRIDS = int(cfg["max_grids"])

if not (
    INST == "ETH-USDT-SWAP"
    and cfg["td_mode"] == "cross"
    and cfg["direction"] == "long"
    and cfg["buy_type"] == "post_only"
    and cfg["tp_type"] == "attached_limit"
    and STEP == Decimal("0.25")
    and TP == Decimal("1.75")
    and QTY == Decimal("0.01")
    and ACTIVE == 20
    and MAX_GRIDS == 500
    and int(cfg["max_exchange_orders"]) == 500
):
    raise SystemExit("STOP: Unexpected bot configuration")

print(f"=== OKX BOT01 v{VERSION} ===")
print("Mode: DRY RUN")
print("Instrument:", INST)
print("Grid step:", STEP)
print("Take Profit:", TP)
print("TP steps:", TP / STEP)
print("Order size:", QTY, "contracts")
print("Active BUY:", ACTIVE)
print("Max grids:", MAX_GRIDS)
print("Margin: CROSS")
print("Leverage: managed manually")
print()

def grid_from_bid(bid):
    # Highest BUY strictly below current BID
    top = (
        bid / STEP
    ).to_integral_value(rounding=ROUND_FLOOR) * STEP

    if top >= bid:
        top -= STEP

    levels = []

    for i in range(ACTIVE):
        buy = top - STEP * i
        tp = buy + TP

        if buy <= 0:
            raise ValueError("Invalid grid price")

        levels.append((buy, tp))

    return levels


ws = None

try:
    print("Connecting to OKX public WebSocket...")

    ws = websocket.create_connection(
        "wss://ws.okx.com/ws/v5/public",
        timeout=15,
        header=["User-Agent: curl/8.5.0"]
    )

    ws.send(json.dumps({
        "op": "subscribe",
        "args": [{
            "channel": "tickers",
            "instId": INST
        }]
    }))

    while True:
        raw = ws.recv()

        if raw == "ping":
            ws.send("pong")
            continue

        msg = json.loads(raw)

        if msg.get("event") == "error":
            raise RuntimeError(str(msg))

        if not msg.get("data"):
            continue

        bid = Decimal(msg["data"][0]["bidPx"])
        levels = grid_from_bid(bid)

        print()
        print("✅ LIVE BID:", bid)
        print()
        print(" #    BUY LIMIT      TP LIMIT")
        print("--------------------------------")

        for i, (buy, tp) in enumerate(levels, 1):
            print(f"{i:2d}    {buy:10.2f}    {tp:10.2f}")

        print("--------------------------------")
        print("BUY levels:", len(levels))
        print("Range:", levels[-1][0], "→", levels[0][0])
        print("TP distance:", TP)
        print()
        print("✅ GRID CALCULATION COMPLETE")
        print("No orders submitted.")
        break

except Exception as e:
    print("❌ ERROR:", type(e).__name__, str(e))

finally:
    if ws:
        ws.close()
