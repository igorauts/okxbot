import json, hmac, hashlib, base64, urllib.request
from datetime import datetime, timezone

env = {}
with open(".env") as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip('"').strip("'")

def get(path):
    ts = datetime.now(timezone.utc).isoformat(
        timespec="milliseconds"
    ).replace("+00:00", "Z")

    msg = ts + "GET" + path
    sig = base64.b64encode(
        hmac.new(
            env["OKX_API_SECRET"].encode(),
            msg.encode(),
            hashlib.sha256
        ).digest()
    ).decode()

    headers = {
        "User-Agent": "curl/8.5.0",
        "OK-ACCESS-KEY": env["OKX_API_KEY"],
        "OK-ACCESS-SIGN": sig,
        "OK-ACCESS-TIMESTAMP": ts,
        "OK-ACCESS-PASSPHRASE": env["OKX_API_PASSPHRASE"]
    }

    if env.get("OKX_DEMO") == "1":
        headers["x-simulated-trading"] = "1"

    req = urllib.request.Request(
        "https://www.okx.com" + path,
        headers=headers
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            result = json.load(r)
    except Exception as e:
        print("ERROR:", type(e).__name__, str(e))
        return []

    if result.get("code") != "0":
        print("API ERROR:", result.get("code"), result.get("msg"))
        return []

    return result.get("data", [])

print("=== OKX ETH TRADING FEES ===")

fees = get(
    "/api/v5/account/trade-fee"
    "?instType=SWAP&instFamily=ETH-USDT"
)

if not fees:
    print("❌ Failed to retrieve fees")

for f in fees:
    print("VIP Level:", f.get("level"))

    groups = f.get("feeGroup", [])

    if groups:
        for g in groups:
            print(
                "Group:", g.get("groupId"),
                "Maker:", g.get("maker"),
                "Taker:", g.get("taker")
            )
    else:
        print("Maker:", f.get("maker"))
        print("Taker:", f.get("taker"))

print("=== COMPLETE ===")
