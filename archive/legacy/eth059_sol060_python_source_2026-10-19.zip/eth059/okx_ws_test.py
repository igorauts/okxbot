import os
import time
import json
import hmac
import base64
import hashlib
import websocket

# Load .env
env = {}
with open(".env") as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip('"').strip("'")

KEY = env.get("OKX_API_KEY", "")
SECRET = env.get("OKX_API_SECRET", "")
PASS = env.get("OKX_API_PASSPHRASE", "")

if not all((KEY, SECRET, PASS)):
    raise SystemExit("❌ Missing API credentials")

demo = env.get("OKX_DEMO", "0") == "1"

URL = (
    "wss://wspap.okx.com/ws/v5/private"
    if demo else
    "wss://ws.okx.com/ws/v5/private"
)

print("=== OKX PRIVATE WEBSOCKET TEST ===")
print("Mode:", "DEMO" if demo else "LIVE")

ws = None

try:
    ws = websocket.create_connection(
        URL,
        timeout=10,
        header=["User-Agent: curl/8.5.0"]
    )

    print("✅ Private WebSocket connected")

    # Authentication
    ts = str(int(time.time()))
    message = ts + "GET" + "/users/self/verify"

    sign = base64.b64encode(
        hmac.new(
            SECRET.encode(),
            message.encode(),
            hashlib.sha256
        ).digest()
    ).decode()

    ws.send(json.dumps({
        "op": "login",
        "args": [{
            "apiKey": KEY,
            "passphrase": PASS,
            "timestamp": ts,
            "sign": sign
        }]
    }))

    response = json.loads(ws.recv())

    if response.get("event") != "login" or response.get("code") != "0":
        print("❌ Authentication failed")
        print("Code:", response.get("code"))
        print("Message:", response.get("msg"))
        raise SystemExit(1)

    print("✅ Authentication successful")

    # Subscribe to order updates
    ws.send(json.dumps({
        "op": "subscribe",
        "args": [{
            "channel": "orders",
            "instType": "SWAP"
        }]
    }))

    response = json.loads(ws.recv())

    if (
        response.get("event") == "subscribe"
        and response.get("arg", {}).get("channel") == "orders"
        and response.get("code", "0") == "0"
    ):
        print("✅ Orders channel subscribed")
        print("   Instrument type: SWAP")
    else:
        print("❌ Subscription failed")
        print("Code:", response.get("code"))
        print("Message:", response.get("msg"))
        raise SystemExit(1)

    print("✅ PRIVATE WEBSOCKET READY")

except Exception as e:
    print("❌ ERROR:", type(e).__name__, str(e))

finally:
    if ws:
        ws.close()

print("=== TEST COMPLETE ===")
