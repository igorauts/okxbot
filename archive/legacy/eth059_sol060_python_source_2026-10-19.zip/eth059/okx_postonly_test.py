import json
import time
import hmac
import hashlib
import base64
import urllib.request
import urllib.error
from datetime import datetime, timezone
from decimal import Decimal, ROUND_FLOOR

env = {}
with open(".env") as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            env[k.strip()] = v.strip().strip('"').strip("'")

BASE = "https://www.okx.com"
INST = "ETH-USDT-SWAP"

def api(method, path, body=None, private=True):
    payload = (
        json.dumps(body, separators=(",", ":"))
        if body is not None else ""
    )

    headers = {
        "User-Agent": "curl/8.5.0",
        "Content-Type": "application/json"
    }

    if private:
        ts = datetime.now(timezone.utc).isoformat(
            timespec="milliseconds"
        ).replace("+00:00", "Z")

        msg = ts + method + path + payload
        sign = base64.b64encode(
            hmac.new(
                env["OKX_API_SECRET"].encode(),
                msg.encode(),
                hashlib.sha256
            ).digest()
        ).decode()

        headers.update({
            "OK-ACCESS-KEY": env["OKX_API_KEY"],
            "OK-ACCESS-SIGN": sign,
            "OK-ACCESS-TIMESTAMP": ts,
            "OK-ACCESS-PASSPHRASE": env["OKX_API_PASSPHRASE"]
        })

    if env.get("OKX_DEMO") == "1":
        headers["x-simulated-trading"] = "1"

    req = urllib.request.Request(
        BASE + path,
        data=payload.encode() if body is not None else None,
        headers=headers,
        method=method
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            result = json.load(r)
    except urllib.error.HTTPError as e:
        print("HTTP ERROR:", e.code, e.read().decode()[:500])
        raise SystemExit(1)
    except Exception as e:
        print("NETWORK ERROR:", str(e))
        print("Do not retry an order submission blindly.")
        raise SystemExit(1)

    if result.get("code") != "0":
        print("API ERROR:", result.get("code"), result.get("msg"))
        raise SystemExit(1)

    return result.get("data", [])

print("=== OKX ETH LIMIT + TP TEST ===")

# Safety: no existing ETH positions or orders
positions = api(
    "GET",
    f"/api/v5/account/positions?instId={INST}"
)

if any(Decimal(p.get("pos") or "0") != 0 for p in positions):
    raise SystemExit("STOP: Existing ETH position detected")

orders = api(
    "GET",
    f"/api/v5/trade/orders-pending?instId={INST}"
)

if orders:
    raise SystemExit("STOP: Existing ETH orders detected")

instrument = api(
    "GET",
    f"/api/v5/public/instruments?instType=SWAP&instId={INST}",
    private=False
)[0]

tick = Decimal(instrument["tickSz"])
size = Decimal("0.01")

if (
    instrument.get("state") != "live"
    or size < Decimal(instrument["minSz"])
    or size % Decimal(instrument["lotSz"]) != 0
):
    raise SystemExit("STOP: Instrument size/state invalid")

ticker = api(
    "GET",
    f"/api/v5/market/ticker?instId={INST}",
    private=False
)[0]

bid = Decimal(ticker["bidPx"])

buy = (
    bid * Decimal("0.995") / Decimal("0.25")
).to_integral_value(rounding=ROUND_FLOOR) * Decimal("0.25")

tp = buy + Decimal("1.75")

cl_id = "OKXTEST" + str(int(time.time() * 1000))
tp_id = "OKXTP" + str(int(time.time() * 1000))

order = {
    "instId": INST,
    "tdMode": "cross",
    "side": "buy",
    "posSide": "net",
    "ordType": "post_only",
    "px": str(buy),
    "sz": str(size),
    "clOrdId": cl_id,
    "attachAlgoOrds": [{
        "attachAlgoClOrdId": tp_id,
        "tpOrdKind": "limit",
        "tpOrdPx": str(tp)
    }]
}

print("Bid:", bid)
print("BUY LIMIT:", buy)
print("TP LIMIT:", tp)
print("Contracts:", size)
print("ETH quantity:", size * Decimal(instrument["ctVal"]))
print("Margin: CROSS")
print("Leverage: unchanged")
print("Estimated notional USDT:",
      buy * size * Decimal(instrument["ctVal"]))

print("\nOrder payload:")
print(json.dumps(order, indent=2))

confirm = input("\nType PLACE to submit LIVE order: ")

if confirm != "PLACE":
    raise SystemExit("Cancelled. No order submitted.")

# Save client IDs before submission
with open("last_eth_test.json", "w") as f:
    json.dump(order, f, indent=2)

import os
os.chmod("last_eth_test.json", 0o600)

print("\nSubmitting order...")

result = api("POST", "/api/v5/trade/order", order)

for r in result:
    print("Order ID:", r.get("ordId"))
    print("Client ID:", r.get("clOrdId"))
    print("Status:", r.get("sCode"))
    print("Message:", r.get("sMsg"))

    if r.get("sCode") == "0" and r.get("ordId"):
        details = api(
            "GET",
            f"/api/v5/trade/order?instId={INST}&ordId={r['ordId']}"
        )
        if details:
            d = details[0]
            print("Order state:", d.get("state"))
            print("Attached TP:", json.dumps(
                d.get("attachAlgoOrds", []),
                indent=2
            ))

print("=== COMPLETE ===")
