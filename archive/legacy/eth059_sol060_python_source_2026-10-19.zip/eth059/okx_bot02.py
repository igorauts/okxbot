import json
import os
import hmac
import hashlib
import base64
import urllib.request
import urllib.error
from datetime import datetime, timezone
from decimal import Decimal, ROUND_FLOOR
from pathlib import Path
import websocket

VERSION = "0.2.0"
ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT / "config.json").read_text())

# This version must NEVER submit orders.
if CFG.get("live_trading") is not False:
    raise SystemExit("STOP: v0.2.0 supports DRY RUN only")

STEP = Decimal(CFG["grid_step"])
TP = Decimal(CFG["take_profit"])
QTY = Decimal(CFG["order_size"])
ACTIVE = int(CFG["active_buy_orders"])
CAP = int(CFG["max_grids"])
EXCHANGE_CAP = int(CFG["max_exchange_orders"])
INST = CFG["instrument"]

if (
    STEP != Decimal("0.25")
    or TP != Decimal("1.75")
    or QTY != Decimal("0.01")
    or ACTIVE != 20
    or CAP != 500
    or EXCHANGE_CAP != 500
    or INST != "ETH-USDT-SWAP"
    or CFG["td_mode"] != "cross"
    or CFG["buy_type"] != "post_only"
    or CFG["tp_type"] != "attached_limit"
):
    raise SystemExit("STOP: Unexpected configuration")

env = {}

for line in (ROOT / ".env").read_text().splitlines():
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        env[k.strip()] = v.strip().strip('"').strip("'")

if not all(env.get(k) for k in (
    "OKX_API_KEY", "OKX_API_SECRET", "OKX_API_PASSPHRASE"
)):
    raise SystemExit("STOP: Missing API credentials")


def api_get(path, private=True):
    headers = {"User-Agent": "curl/8.5.0"}

    if private:
        ts = datetime.now(timezone.utc).isoformat(
            timespec="milliseconds"
        ).replace("+00:00", "Z")

        message = ts + "GET" + path

        signature = base64.b64encode(
            hmac.new(
                env["OKX_API_SECRET"].encode(),
                message.encode(),
                hashlib.sha256
            ).digest()
        ).decode()

        headers.update({
            "OK-ACCESS-KEY": env["OKX_API_KEY"],
            "OK-ACCESS-SIGN": signature,
            "OK-ACCESS-TIMESTAMP": ts,
            "OK-ACCESS-PASSPHRASE": env["OKX_API_PASSPHRASE"]
        })

    if env.get("OKX_DEMO", "0") == "1":
        headers["x-simulated-trading"] = "1"

    req = urllib.request.Request(
        "https://www.okx.com" + path,
        headers=headers
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            result = json.load(r)
    except urllib.error.HTTPError as e:
        raise RuntimeError(
            f"HTTP {e.code}: "
            f"{e.read(300).decode(errors='replace')}"
        )

    if result.get("code") != "0":
        raise RuntimeError(
            f"OKX {result.get('code')}: {result.get('msg')}"
        )

    return result.get("data", [])


def get_bid():
    ws = websocket.create_connection(
        "wss://ws.okx.com/ws/v5/public",
        timeout=12,
        header=["User-Agent: curl/8.5.0"]
    )

    try:
        ws.send(json.dumps({
            "op": "subscribe",
            "args": [{
                "channel": "tickers",
                "instId": INST
            }]
        }))

        for _ in range(15):
            raw = ws.recv()

            if raw == "ping":
                ws.send("pong")
                continue

            msg = json.loads(raw)

            if msg.get("event") == "error":
                raise RuntimeError(str(msg))

            for item in msg.get("data", []):
                if (
                    item.get("instId") == INST
                    and item.get("bidPx")
                ):
                    return Decimal(item["bidPx"])

        raise RuntimeError("No BID received")

    finally:
        ws.close()


def floor_grid(price):
    return (
        (price / STEP).to_integral_value(
            rounding=ROUND_FLOOR
        ) * STEP
    )


def build_grid(bid, occupied=None):
    occupied = occupied or set()

    top = floor_grid(bid)

    if top >= bid:
        top -= STEP

    levels = []
    price = top

    while len(levels) < ACTIVE:
        if price <= 0:
            raise RuntimeError("Invalid grid price")

        if price not in occupied:
            levels.append(price)

        price -= STEP

    return levels


class GridMachine:
    """
    In-memory state-machine test.
    Events here are synthetic, not actual exchange fills.
    """

    def __init__(self, levels):
        self.open_buy = set(levels)
        self.wait_tp = {}
        self.processed = set()

    def occupied_count(self):
        return len(self.open_buy) + len(self.wait_tp)

    def replenish_bottom(self):
        while (
            len(self.open_buy) < ACTIVE
            and self.occupied_count() < CAP
        ):
            if not self.open_buy:
                raise RuntimeError(
                    "Cannot replenish without an anchor"
                )

            price = min(self.open_buy) - STEP

            while (
                price in self.open_buy
                or price in self.wait_tp
            ):
                price -= STEP

            if price <= 0:
                raise RuntimeError("Invalid grid price")

            self.open_buy.add(price)

    def buy_filled(self, price, event_id):
        if event_id in self.processed:
            return False

        if price not in self.open_buy:
            raise RuntimeError("Unexpected BUY fill")

        self.open_buy.remove(price)
        self.wait_tp[price] = price + TP
        self.processed.add(event_id)

        self.replenish_bottom()
        return True

    def tp_filled(self, price, event_id):
        if event_id in self.processed:
            return False

        if price not in self.wait_tp:
            raise RuntimeError("Unexpected TP fill")

        del self.wait_tp[price]

        # Rearm original level.
        self.open_buy.add(price)

        # Remove lowest excess BUY.
        if len(self.open_buy) > ACTIVE:
            self.open_buy.remove(min(self.open_buy))

        self.processed.add(event_id)
        return True


def test_state_machine(levels):
    machine = GridMachine(levels)
    highest = max(levels)

    # Simulated full BUY execution.
    assert machine.buy_filled(highest, "SIM_BUY_1")

    # Same event must not be processed twice.
    assert not machine.buy_filled(
        highest, "SIM_BUY_1"
    )

    assert len(machine.open_buy) == ACTIVE
    assert len(machine.wait_tp) == 1
    assert machine.wait_tp[highest] == highest + TP

    # Simulated full TP execution.
    assert machine.tp_filled(highest, "SIM_TP_1")

    assert not machine.tp_filled(
        highest, "SIM_TP_1"
    )

    assert len(machine.open_buy) == ACTIVE
    assert len(machine.wait_tp) == 0
    assert highest in machine.open_buy

    print("✅ State-machine transition test passed")
    print("✅ Duplicate event protection passed")
    print("✅ TP rearm test passed")


def main():
    print(f"=== OKX BOT01 v{VERSION} ===")
    print("Mode: DRY RUN")
    print("No trading requests supported")
    print()

    if env.get("OKX_DEMO", "0") != "0":
        raise RuntimeError("Expected LIVE account")

    account = api_get("/api/v5/account/config")

    if not account or account[0].get("posMode") != "net_mode":
        raise RuntimeError("Unexpected position mode")

    positions = api_get(
        f"/api/v5/account/positions?instId={INST}"
    )

    active_positions = [
        p for p in positions
        if Decimal(p.get("pos") or "0") != 0
    ]

    orders = api_get(
        f"/api/v5/trade/orders-pending?instId={INST}"
    )

    algos = []

    for kind in (
        "conditional", "oco", "trigger", "move_order_stop"
    ):
        algos.extend(api_get(
            "/api/v5/trade/orders-algo-pending"
            f"?ordType={kind}&instId={INST}"
        ))

    print("Positions:", len(active_positions))
    print("Orders:", len(orders))
    print("Algo orders:", len(algos))

    if active_positions or orders or algos:
        raise RuntimeError(
            "STOP: Existing exposure detected"
        )

    instruments = api_get(
        "/api/v5/public/instruments"
        f"?instType=SWAP&instId={INST}",
        private=False
    )

    if len(instruments) != 1:
        raise RuntimeError("Invalid instrument response")

    info = instruments[0]

    tick = Decimal(info["tickSz"])
    lot = Decimal(info["lotSz"])
    minimum = Decimal(info["minSz"])

    if (
        info["state"] != "live"
        or STEP % tick != 0
        or TP % tick != 0
        or QTY < minimum
        or QTY % lot != 0
    ):
        raise RuntimeError("Instrument validation failed")

    bid = get_bid()
    levels = build_grid(bid)

    if len(levels) > min(ACTIVE, CAP, EXCHANGE_CAP):
        raise RuntimeError("Capacity exceeded")

    print("\n=== GRID ===")
    print("BID:", bid)
    print("Grid step:", STEP)
    print("TP:", TP)
    print("TP steps:", TP / STEP)
    print("Active BUY:", ACTIVE)
    print("Max grids:", CAP)

    proposed = []

    for i, buy in enumerate(levels, 1):
        tp = buy + TP

        order = {
            "instId": INST,
            "tdMode": "cross",
            "side": "buy",
            "posSide": "net",
            "ordType": "post_only",
            "px": f"{buy:.2f}",
            "sz": str(QTY),
            "attachAlgoOrds": [{
                "tpOrdKind": "limit",
                "tpOrdPx": f"{tp:.2f}"
            }]
        }

        proposed.append(order)
        print(f"{i:2d}. BUY {buy:.2f} → TP {tp:.2f}")

    print("\n=== STATE TESTS ===")
    test_state_machine(levels)

    snapshot = {
        "format": "OKX-v0.2.0-PREVIEW-ONLY",
        "timestamp": datetime.now(
            timezone.utc
        ).isoformat(),
        "bid": str(bid),
        "planned_buy_count": len(proposed),
        "planned_orders": proposed,
        "note": "Not live state. No orders submitted."
    }

    path = ROOT / "state" / "preview_v020.json"
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_suffix(".tmp")

    with os.fdopen(
        os.open(
            temp,
            os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
            0o600
        ),
        "w"
    ) as f:
        json.dump(snapshot, f, indent=2)
        f.flush()
        os.fsync(f.fileno())

    os.replace(temp, path)

    print("\n✅ Preview saved:", path)
    print("✅ NO ORDERS SUBMITTED")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        raise SystemExit(
            f"❌ {type(e).__name__}: {e}"
        )
