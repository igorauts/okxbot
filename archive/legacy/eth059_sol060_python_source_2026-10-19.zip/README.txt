Legacy OKX bot Python sources: eth059 (bot01), sol060 (bot02).
For historical reference only; not safe to run.
Credentials, config, logs, state, trade data, and venv are NOT included.
Retired 2026-10-19; this archive is NOT runtime code.
